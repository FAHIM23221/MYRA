# MYRA v3.0 — AI Companion

A real, functional, voice-first AI companion for Android, rebuilt from the
MYRA 2.0.0 architecture (package `com.myra.assistant`) against the full
18-section functional specification.

- **Package:** `com.myra.assistant`
- **Version:** 3.0.0 (versionCode 3)
- **minSdk 26** (Android 8.0) · **targetSdk 35** (Android 15) · Kotlin 1.9.22 · MVVM
- **AGP 8.4.0 · Gradle 8.6**

## What it does

| Area | Implementation |
|---|---|
| Voice conversation | SpeechRecognizer STT (Bengali `bn-BD` / English, partial results) + TTS, continuous conversation, barge-in (interrupt while speaking), adjustable rate/voice/tone |
| AI brain | Gemini Live WebSocket (`gemini-2.5-flash-native-audio-preview-12-2025`) + REST fallback (`gemini-2.5-flash:generateContent`); user-entered API key only |
| Emotion engine | Bengali+English mood detection (happy/sad/angry/stressed/lonely/tired/excited/busy/joking), adaptive tone, empathetic replies, respectful disagreement; MYRA never claims human feelings |
| Persistent memory | Room database (`memories`, `contacts`, `reminders`, `routines`, `turns`) + EncryptedSharedPreferences for keys; view / correct / export (JSON) / delete in the Memory screen; nothing stored without consent; memories are never invented |
| Screen understanding | AccessibilityService (window content + gestures) + ML Kit on-device OCR; “Look at my screen / explain / read / find / what should I tap”; confirmation before any sensitive action |
| Device control | Open apps, calls, SMS, flashlight, volume, alarms, reminders, notes, web search, gallery |
| Call assistant | Caller-name announcement, answer/reject by voice (“Answer” / “Reject”, Bengali + English), WhatsApp calls |
| App Lock | PIN / pattern / voice passphrase / fingerprint (BiometricPrompt), salted hashes, 5-wrong = 5-minute lockout, AES-256-GCM via Android Keystore |
| Background / wake word | Foreground service with notification, user-configurable wake word (default “myra”), can be fully disabled; power-button double-press to summon; boot recovery |
| Orb | 9 animated states: Idle, Listening, Processing, Speaking, Thinking, Emotionally responsive, Connecting, Disconnected, Error |
| Proactive reminders | WorkManager (15 min), quiet hours, easy disable |
| Multi-user | Separate contexts for Owner / enrolled Contact / Guest. Guests see **no** private memory and get a visible “GUEST MODE” indicator. Owner verification via BiometricPrompt / PIN / pattern |
| Privacy (hard rule) | **No facial-recognition identification.** No face templates, embeddings, or template matching anywhere. Gallery person profiles are created only from the name + relationship + notes *you* type or speak, with consent. ML Kit Face Detection is used only to detect face *presence* in a photo. In a session, a person is “recognised” only when they state their name and the owner confirms it — otherwise they are treated as Guest/unknown. |

## How to build

Requirements: JDK 17, Android SDK with platform 35 + build-tools 35.0.0.

```bash
# 1. Point the SDK at your install (edit sdk.dir)
echo "sdk.dir=$ANDROID_HOME" > local.properties

# 2. Build (Gradle wrapper is included; needs internet for dependencies)
./gradlew :app:assembleDebug

# APK:
#   app/build/outputs/apk/debug/app-debug.apk
```

> The wrapper downloads Gradle 8.6 on first run. If your network needs a
> proxy, pass `-DsystemProp.https.proxyHost=… -DsystemProp.https.proxyPort=…`
> (and user/password if required) to the Gradle command.

## Entering your Gemini API key

1. Open MYRA → **Settings** (gear icon).
2. Under **Gemini API Key**, paste your key and tap **Save Settings**.
3. The key is stored in EncryptedSharedPreferences (AES-256-GCM, Keystore)
   and is never logged, never displayed in full, and never shipped in the app.
   Get a key at <https://aistudio.google.com/app/apikey>.
4. Optional: add an ElevenLabs TTS key in the same screen and choose
   **Voice Engine → ElevenLabs**.

Without a key, MYRA still works for on-device commands (open apps, calls,
flashlight, volume, alarms, screen reading, app lock) but AI chat replies
will report the missing key and offer to open Settings.

## Required permissions (and why)

| Permission | Used for |
|---|---|
| `RECORD_AUDIO`, `FOREGROUND_SERVICE_MICROPHONE` | Voice input / live conversation |
| `INTERNET`, `ACCESS_NETWORK_STATE` | Gemini Live + REST |
| `CAMERA` | Face-*presence* check on a photo you pick; flashlight |
| `READ/WRITE_CONTACTS` | Call/SMS by name, Prime Contact |
| `READ_PHONE_STATE`, `READ_CALL_LOG`, `CALL_PHONE`, `ANSWER_PHONE_CALLS` | Call announce / answer / reject |
| `SEND_SMS` | Voice SMS |
| `QUERY_ALL_PACKAGES` | Open apps by name, app-lock selection |
| `SYSTEM_ALERT_WINDOW` | Floating overlay orb |
| `RECEIVE_BOOT_COMPLETED` | Restart background service after reboot |
| `POST_NOTIFICATIONS` | Foreground-service + reminder notifications |
| `USE_BIOMETRIC` | Fingerprint owner verification |
| `READ_MEDIA_IMAGES` | Gallery photo pick for a contact profile |
| `SCHEDULE_EXACT_ALARM`, `SET_ALARM` | Voice alarms |
| Accessibility Service + Device Admin | Screen understanding / gestures, app lock enforcement (both opt-in, granted by the user in system Settings) |

## Project layout

```
app/src/main/java/com/myra/assistant/
  ai/            EmotionEngine, CommandProcessor, GeminiClient, ConversationManager
  voice/         VoiceManager (STT/TTS), GeminiLiveClient (WebSocket)
  data/          MyraDatabase (Room), MyraDao, MemoryEntity, MemoryRepository, SecurePrefs
  screen/        ScreenVision (OCR), FacePresenceDetector (presence-only)
  automation/    DeviceController
  service/       AccessibilityHelperService, CallMonitorService, MyraOverlayService,
                 BootReceiver, PowerButtonReceiver, MyraDeviceAdminReceiver, CallAssistant
  services/      ForegroundVoiceService
  work/          ReminderWorker (WorkManager)
  security/      SecurityManager, AppLockActivity, PatternSetupActivity,
                 SecuritySettingsActivity, AppSelectionActivity, BiometricManager
  ui/main/       MainActivity, MainViewModel, OrbView, ChatAdapter, CallAssistantActivity
  ui/settings/   SettingsActivity
  ui/memory/     MemoryActivity, ContactProfileActivity
  models/        Mood, PersonalityMode, SessionRole, OrbState, CommandType, …
  utils/         Constants, Logger (never logs keys/PINs/content)
app/src/test/    EmotionEngineTest, CommandProcessorTest (40 tests)
```

## Security posture

- `debuggable=false` even for debug builds; `usesCleartextTraffic=false`;
  network security config trusts system CAs only; `allowBackup=false`.
- No hardcoded API keys or credentials; no secrets in logs (`Logger.redact`).
- PIN / pattern / voice passphrase stored only as salted SHA-256 hashes.
- See [SPEC_COVERAGE.md](SPEC_COVERAGE.md) for the honest per-section status
  and [BUILD_REPORT.md](BUILD_REPORT.md) for what was verified on this machine.
