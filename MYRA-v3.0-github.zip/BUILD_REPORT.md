# MYRA v3.0 — Build Report

Date: 2026-11-06. Machine: Linux VM (no JDK / Android SDK pre-installed).
Original APK was **not** modified; all work is new source in this project.

## Environment setup (commands run)

```bash
# JDK 17 (apt install went to /usr, which this VM discards on restart —
# so Temurin 17.0.21 was installed persistently under ~/workspace/jdk17)
wget https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse
tar -xzf jdk17.tar.gz -C ~/workspace/jdk17 --strip-components=1
~/workspace/jdk17/bin/java -version
# -> openjdk version "17.0.21" 2026-10-20, Temurin-17.0.21+9

# Android SDK command-line tools (persistent, ~/workspace/.android-sdk)
# platform android-35 (platform-35_r02.zip), build-tools 35.0.0
# (build-tools_r35_linux.zip), platform-tools — downloaded with curl
# from dl.google.com and unzipped by hand (sdkmanager itself could not
# run — see below). aapt2 verified:
~/workspace/.android-sdk/build-tools/35.0.0/aapt2 version
# -> Android Asset Packaging Tool (aapt) 2.19-11948202

# Gradle 8.6 (curl download; the wrapper could not fetch it — see below)
curl -sL -o gradle-8.6-bin.zip https://services.gradle.org/distributions/gradle-8.6-bin.zip
unzip gradle-8.6-bin.zip -d ~/workspace/

# Kotlin compiler 1.9.22 (for direct verification)
curl -sL -o kotlin-compiler.zip \
  https://github.com/JetBrains/kotlin/releases/download/v1.9.22/kotlin-compiler-1.9.22.zip
```

`local.properties` in this project points at the persistent SDK:
`sdk.dir=/home/hatch/workspace/.android-sdk` (edit it on another machine).

## What was verified — with exact results

### 1. Unit tests: PASS (40/40)

```bash
export JAVA_HOME=~/workspace/jdk17 PATH=~/workspace/jdk17/bin:$PATH
kotlinc models/Models.kt utils/Constants.kt utils/Logger.kt \
  ai/EmotionEngine.kt ai/CommandProcessor.kt \
  EmotionEngineTest.kt CommandProcessorTest.kt \
  -cp android-35/android.jar:junit-4.13.2.jar:hamcrest-core-1.3.jar \
  -d myra-test-classes
# exit=0, 0 errors
java -cp myra-test-classes:android.jar:junit-4.13.2.jar:hamcrest-core-1.3.jar:\
kotlin-stdlib.jar org.junit.runner.JUnitCore \
  com.myra.assistant.EmotionEngineTest com.myra.assistant.CommandProcessorTest
# JUnit version 4.13.2 — OK (40 tests)
```

### 2. Resources: aapt2 compile PASS (25 files)

```bash
aapt2 compile <each file under app/src/main/res> -o aapt2-out/
# exit=0, 25 .flat files, no errors
```

Cross-checks also passed: every `@color/…` and `@string/…` used in
layouts/themes resolves to a definition; every `com.myra.assistant.*`
import in the 43 Kotlin files resolves to a real class (the only
unresolved names are `R` and `databinding.*`, which AGP generates);
no duplicate class names; 66 classes total.

### 3. Standalone aapt2 link: NOT APPLICABLE (expected)

Linking resources outside Gradle fails because `themes.xml` inherits from
`Theme.Material3.DayNight.NoActionBar` and uses Material3 attributes —
those come from the `material` AAR, which only Gradle merges at build
time. This is not a project error; the same link succeeds inside a
Gradle build. (The standalone link was retried with a temporary manifest
copy carrying `package="com.myra.assistant"`; the project manifest
correctly uses the AGP `namespace` instead.)

### 4. Full Gradle build (`./gradlew :app:assembleDebug`): NOT RUN — blocked by the sandbox

**No APK was produced. No successful Gradle build is claimed.**

Two independent environment failures, both proven, not project errors:

(a) **Java `HttpURLConnection` + this egress proxy is broken.**
The Gradle wrapper and `sdkmanager` both fail identically:
`java.util.NoSuchElementException at …HttpURLConnection.doTunneling0`.
curl/wget to the same URLs work fine. Worked around by downloading the
Gradle 8.6 distribution and the SDK zips directly with curl.

(b) **Gradle daemon IPC is intercepted in this sandbox.**
The daemon starts and listens on 127.0.0.1, but the client fails with
`Could not receive a message from the daemon … Unexpected type tag 109`.
A minimal Java test proves why: a Java socket connecting to a Python
server on `127.0.0.1:54321` receives `muse: Other TCP …` instead of the
server’s bytes — Java localhost TCP is redirected to a sandbox service.
(The same test in Python receives the correct bytes.) Gradle’s
daemon protocol is Java-to-Java localhost TCP, so no Gradle build —
daemon or `--no-daemon` (which still forks a single-use daemon) — can
communicate here. This affects only this sandbox; the project itself
uses a standard Gradle 8.6 / AGP 8.4.0 setup.

## What was NOT verified

- The full Gradle build and a signed/installed APK (blocked as above).
- On-device / emulator end-to-end testing of voice, Gemini Live,
  accessibility gestures, calls, and reminders.
- Room annotation processing (KSP) — the Room code follows the standard
  documented API, but KSP only runs inside Gradle.

## To build on a normal machine

```bash
echo "sdk.dir=$ANDROID_HOME" > local.properties
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Then install, grant the permissions listed in the README, enter a Gemini
API key in Settings, and run the on-device checks in SPEC_COVERAGE.md §18.

## Deliverables in this project

- 43 Kotlin source files (~4,050 lines) + 2 test files (40 tests)
- 25 resource files (17 layouts, values, xml, drawables)
- `README.md`, `SPEC_COVERAGE.md`, this `BUILD_REPORT.md`
- `gradlew` + `gradle/wrapper/gradle-wrapper.{properties,jar}` (Gradle 8.6)
- No APK in `output/` — see §4 above.
