# MYRA v3.0 ProGuard rules
-keep class com.myra.assistant.** { *; }
-keep class androidx.room.** { *; }
-dontwarn com.google.mlkit.**
-keepattributes *Annotation*
