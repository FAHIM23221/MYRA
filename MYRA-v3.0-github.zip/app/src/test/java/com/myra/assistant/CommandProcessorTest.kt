package com.myra.assistant

import com.myra.assistant.ai.CommandProcessor
import com.myra.assistant.models.CommandType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandProcessorTest {

    @Test
    fun openAppEnglish() {
        val cmd = CommandProcessor.parse("open YouTube")
        assertEquals(CommandType.OPEN_APP, cmd.type)
        assertEquals("youtube", cmd.arg)
    }

    @Test
    fun openAppBengali() {
        val cmd = CommandProcessor.parse("ইউটিউব খোলো")
        assertEquals(CommandType.OPEN_APP, cmd.type)
        assertEquals("ইউটিউব", cmd.arg)
    }

    @Test
    fun callEnglish() {
        val cmd = CommandProcessor.parse("call Ammu")
        assertEquals(CommandType.CALL, cmd.type)
        assertEquals("ammu", cmd.arg)
    }

    @Test
    fun callBengali() {
        val cmd = CommandProcessor.parse("আম্মুকে কল করো")
        assertEquals(CommandType.CALL, cmd.type)
        assertEquals("আম্মু", cmd.arg)
    }

    @Test
    fun whatsappCall() {
        val cmd = CommandProcessor.parse("whatsapp call Rafi")
        assertEquals(CommandType.WHATSAPP_CALL, cmd.type)
        assertEquals("rafi", cmd.arg)
    }

    @Test
    fun smsEnglish() {
        val cmd = CommandProcessor.parse("sms Rafi I will be late")
        assertEquals(CommandType.SMS, cmd.type)
        assertEquals("rafi", cmd.arg)
        assertEquals("i will be late", cmd.arg2)
    }

    @Test
    fun smsBengali() {
        val cmd = CommandProcessor.parse("রাফিকে মেসেজ করো আমি আসছি")
        assertEquals(CommandType.SMS, cmd.type)
        assertEquals("রাফি", cmd.arg)
        assertEquals("আমি আসছি", cmd.arg2)
    }

    @Test
    fun playMusic() {
        val cmd = CommandProcessor.parse("play Arijit Singh")
        assertEquals(CommandType.PLAY_MUSIC, cmd.type)
        assertEquals("arijit singh", cmd.arg)
    }

    @Test
    fun playMusicBengali() {
        val cmd = CommandProcessor.parse("গান চালাও")
        assertEquals(CommandType.PLAY_MUSIC, cmd.type)
    }

    @Test
    fun spotifyPlay() {
        val cmd = CommandProcessor.parse("play lofi beats on spotify")
        assertEquals(CommandType.SPOTIFY_PLAY, cmd.type)
        assertEquals("lofi beats", cmd.arg)
    }

    @Test
    fun flashlightOnOff() {
        assertEquals(CommandType.FLASHLIGHT_ON, CommandProcessor.parse("flashlight on").type)
        assertEquals(CommandType.FLASHLIGHT_OFF, CommandProcessor.parse("flashlight off").type)
        assertEquals(CommandType.FLASHLIGHT_ON, CommandProcessor.parse("টর্চ জ্বালাও").type)
        assertEquals(CommandType.FLASHLIGHT_OFF, CommandProcessor.parse("টর্চ বন্ধ করো").type)
    }

    @Test
    fun volumeUpDown() {
        assertEquals(CommandType.VOLUME_UP, CommandProcessor.parse("volume up").type)
        assertEquals(CommandType.VOLUME_DOWN, CommandProcessor.parse("ভলিউম কমাও").type)
    }

    @Test
    fun search() {
        val cmd = CommandProcessor.parse("search best biryani in Dhaka")
        assertEquals(CommandType.SEARCH, cmd.type)
        assertEquals("best biryani in dhaka", cmd.arg)
        val bn = CommandProcessor.parse("ঢাকার আবহাওয়া খুঁজো")
        assertEquals(CommandType.SEARCH, bn.type)
    }

    @Test
    fun setAlarm() {
        assertEquals(CommandType.SET_ALARM, CommandProcessor.parse("set alarm for 7 am").type)
        assertEquals(CommandType.SET_ALARM, CommandProcessor.parse("অ্যালার্ম দাও").type)
    }

    @Test
    fun setReminder() {
        assertEquals(CommandType.SET_REMINDER, CommandProcessor.parse("remind me to call mom").type)
        assertEquals(CommandType.SET_REMINDER, CommandProcessor.parse("মনে করিয়ে দাও").type)
    }

    @Test
    fun createNote() {
        val cmd = CommandProcessor.parse("create note buy milk tomorrow")
        assertEquals(CommandType.CREATE_NOTE, cmd.type)
        assertEquals("buy milk tomorrow", cmd.arg)
    }

    @Test
    fun lookAtScreen() {
        assertEquals(CommandType.LOOK_AT_SCREEN, CommandProcessor.parse("look at my screen").type)
        assertEquals(CommandType.LOOK_AT_SCREEN, CommandProcessor.parse("স্ক্রিন দেখো").type)
    }

    @Test
    fun explainAndReadScreen() {
        assertEquals(CommandType.EXPLAIN_SCREEN, CommandProcessor.parse("explain my screen").type)
        assertEquals(CommandType.READ_SCREEN, CommandProcessor.parse("read my screen").type)
    }

    @Test
    fun findOnScreen() {
        val cmd = CommandProcessor.parse("find the login button")
        assertEquals(CommandType.FIND_ON_SCREEN, cmd.type)
        assertEquals("the login button", cmd.arg)
    }

    @Test
    fun unknownForConversation() {
        val cmd = CommandProcessor.parse("how are you doing today?")
        assertEquals(CommandType.UNKNOWN, cmd.type)
        assertNull(cmd.arg)
    }

    @Test
    fun isDirectCommand() {
        assertTrue(CommandProcessor.isDirectCommand("open Spotify"))
        assertTrue(CommandProcessor.isDirectCommand("টর্চ জ্বালাও"))
        assertFalse(CommandProcessor.isDirectCommand("tell me a story"))
        assertFalse(CommandProcessor.isDirectCommand(""))
    }
}
