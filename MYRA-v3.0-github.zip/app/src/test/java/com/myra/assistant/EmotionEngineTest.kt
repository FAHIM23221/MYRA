package com.myra.assistant

import com.myra.assistant.ai.EmotionEngine
import com.myra.assistant.models.Mood
import com.myra.assistant.models.PersonalityMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EmotionEngineTest {

    @Test
    fun happyEnglish_detected() {
        assertEquals(Mood.HAPPY, EmotionEngine.detectMood("I am so happy today, this is great!"))
    }

    @Test
    fun happyBengali_detected() {
        assertEquals(Mood.HAPPY, EmotionEngine.detectMood("আজ খুব খুশি লাগছে, ভালো লাগছে"))
    }

    @Test
    fun sadBengali_detected() {
        assertEquals(Mood.SAD, EmotionEngine.detectMood("মন খারাপ, খুব কষ্ট হচ্ছে"))
    }

    @Test
    fun sadEnglish_detected() {
        assertEquals(Mood.SAD, EmotionEngine.detectMood("I feel sad and I want to cry"))
    }

    @Test
    fun angryDetected() {
        assertEquals(Mood.ANGRY, EmotionEngine.detectMood("আমি খুব রাগ করেছি, বিরক্ত লাগছে"))
        assertEquals(Mood.ANGRY, EmotionEngine.detectMood("I am furious and angry right now"))
    }

    @Test
    fun stressedDetected() {
        assertEquals(Mood.STRESSED, EmotionEngine.detectMood("অনেক টেনশন হচ্ছে, চাপ বাড়ছে"))
        assertEquals(Mood.STRESSED, EmotionEngine.detectMood("I am so stressed and worried"))
    }

    @Test
    fun lonelyDetected() {
        assertEquals(Mood.LONELY, EmotionEngine.detectMood("আমি একা, কেউ নেই পাশে"))
        assertEquals(Mood.LONELY, EmotionEngine.detectMood("I feel so lonely"))
    }

    @Test
    fun tiredDetected() {
        assertEquals(Mood.TIRED, EmotionEngine.detectMood("খুব ক্লান্ত লাগছে, ঘুম পাচ্ছে"))
        assertEquals(Mood.TIRED, EmotionEngine.detectMood("I am tired and sleepy"))
    }

    @Test
    fun excitedDetected() {
        assertEquals(Mood.EXCITED, EmotionEngine.detectMood("Wow! This is amazing, I am so excited!"))
    }

    @Test
    fun busyDetected() {
        assertEquals(Mood.BUSY, EmotionEngine.detectMood("আমি ব্যস্ত আছি, পরে কথা বলি"))
        assertEquals(Mood.BUSY, EmotionEngine.detectMood("I am busy, talk later, no time"))
    }

    @Test
    fun jokingDetected() {
        assertEquals(Mood.JOKING, EmotionEngine.detectMood("হাহা, এটা খুব মজা 😂"))
        assertEquals(Mood.JOKING, EmotionEngine.detectMood("lol that was so funny"))
    }

    @Test
    fun neutral_whenNoKeywords() {
        assertEquals(Mood.NEUTRAL, EmotionEngine.detectMood("What is the weather today?"))
    }

    @Test
    fun recentTurnsInfluenceMood() {
        val mood = EmotionEngine.detectMood(
            "I don't know",
            recentTurns = listOf("আমার মন খারাপ", "খুব কষ্ট হচ্ছে")
        )
        assertEquals(Mood.SAD, mood)
    }

    @Test
    fun adaptReply_busyShortensToTwoSentences() {
        val long = "First sentence. Second sentence. Third sentence. Fourth sentence."
        val adapted = EmotionEngine.adaptReply(long, Mood.BUSY, PersonalityMode.ASSISTANT)
        assertTrue(adapted.contains("First sentence"))
        assertTrue(adapted.contains("Second sentence"))
        assertTrue(!adapted.contains("Third sentence"))
    }

    @Test
    fun adaptReply_sadIsEmpatheticNotMotivationalSpam() {
        val adapted = EmotionEngine.adaptReply("I understand.", Mood.SAD, PersonalityMode.GF_CARING)
        assertTrue(adapted.contains("শুনছি"))
        assertTrue(!adapted.contains("just be positive"))
    }

    @Test
    fun adaptReply_angryHasNoJokes() {
        val adapted = EmotionEngine.adaptReply("Let's fix this.", Mood.ANGRY, PersonalityMode.ASSISTANT)
        assertTrue(adapted.contains("শান্তভাবে"))
        assertTrue(!adapted.contains("😄"))
        assertTrue(!adapted.contains("lol"))
    }

    @Test
    fun adaptReply_tiredIsGentleAndShort() {
        val adapted = EmotionEngine.adaptReply(
            "You should rest now. There is a lot to do tomorrow. We can talk later.",
            Mood.TIRED,
            PersonalityMode.ASSISTANT
        )
        assertTrue(adapted.contains("বিশ্রাম"))
    }

    @Test
    fun adaptReply_happyIsEnthusiastic() {
        val adapted = EmotionEngine.adaptReply("Great news!", Mood.HAPPY, PersonalityMode.ASSISTANT)
        assertTrue(adapted.startsWith("দারুণ!"))
    }

    @Test
    fun respectfulDisagreement_isRespectful() {
        val text = EmotionEngine.respectfulDisagreement("football")
        assertTrue(text.contains("football"))
        assertTrue(text.contains("সম্মান করি"))
    }
}
