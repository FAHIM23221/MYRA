package com.myra.assistant.work

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.myra.assistant.MyraApplication
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Fires due reminders as notifications every 15 minutes.
 *
 * De-duplication is two-layered:
 * 1. One-shot reminders are marked done via repository.updateReminder
 *    (the DAO's getDueReminders only returns done = 0), so they never fire
 *    twice.
 * 2. A notified-ids set in SharedPreferences ("notified_reminder_ids")
 *    guards against double notification within a run / after a crash.
 *    Repeat-daily reminders are never marked done; their dedup key includes
 *    the current date so they can fire again tomorrow.
 * Quiet hours (KEY_QUIET_START / KEY_QUIET_END, minutes since midnight) and
 * the proactive toggle (KEY_PROACTIVE_ENABLED) suppress notifications
 * entirely for that run.
 */
class ReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        const val UNIQUE_WORK_NAME = "myra_reminder_work"
        private const val DEDUP_PREFS = "myra_notified_reminders"
        private const val DEDUP_KEY = "notified_reminder_ids"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<ReminderWorker>(15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Logger.i("ReminderWorker", "Periodic reminder work scheduled (15 min)")
        }
    }

    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(Constants.KEY_PROACTIVE_ENABLED, true)) {
            Logger.i("ReminderWorker", "Proactive reminders disabled — skipping")
            return Result.success()
        }
        if (isQuietHours(prefs.getInt(Constants.KEY_QUIET_START, 23 * 60),
                prefs.getInt(Constants.KEY_QUIET_END, 7 * 60))) {
            Logger.i("ReminderWorker", "In quiet hours — skipping notifications")
            return Result.success()
        }

        val app = applicationContext as? MyraApplication ?: run {
            Logger.e("ReminderWorker", "MyraApplication not available")
            return Result.retry()
        }
        val now = System.currentTimeMillis()
        val due = try {
            app.repository.getDueReminders(now)
        } catch (e: Exception) {
            Logger.e("ReminderWorker", "Failed to load due reminders", e)
            return Result.retry()
        }
        if (due.isEmpty()) return Result.success()

        val dedupPrefs = applicationContext.getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
        val notified = dedupPrefs.getStringSet(DEDUP_KEY, emptySet())?.toMutableSet()
            ?: mutableSetOf()
        createNotificationChannel()

        var newlyNotified = false
        val today = java.text.SimpleDateFormat(
            "yyyy-MM-dd", java.util.Locale.getDefault()
        ).format(java.util.Date())
        for (reminder in due) {
            // Repeat-daily reminders get a per-day dedup key; one-shots use
            // id + trigger time (and are marked done below).
            val key = if (reminder.repeatDaily) {
                "${reminder.id}:${reminder.triggerAtMillis}:$today"
            } else {
                "${reminder.id}:${reminder.triggerAtMillis}"
            }
            if (key in notified) continue
            postReminderNotification(reminder.id, reminder.title)
            notified.add(key)
            newlyNotified = true
            if (!reminder.repeatDaily) {
                runCatching {
                    app.repository.updateReminder(reminder.copy(done = true))
                }.onFailure { e ->
                    Logger.e("ReminderWorker", "Failed to mark reminder done", e)
                }
            }
        }
        if (newlyNotified) {
            dedupPrefs.edit().putStringSet(DEDUP_KEY, notified).apply()
            // Prune the dedup set so it cannot grow without bound.
            if (notified.size > 500) {
                dedupPrefs.edit().putStringSet(DEDUP_KEY, notified.takeLast(200).toSet()).apply()
            }
        }
        return Result.success()
    }

    /** True when the current local time falls inside [startMin, endMin). Handles overnight spans. */
    private fun isQuietHours(startMin: Int, endMin: Int): Boolean {
        if (startMin == endMin) return false
        val now = Calendar.getInstance()
        val current = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        return if (startMin < endMin) {
            current in startMin until endMin
        } else {
            current >= startMin || current < endMin
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            Constants.NOTIF_CHANNEL_REMINDER,
            "MYRA reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Reminders from MYRA" }
        (applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun postReminderNotification(reminderId: Long, title: String) {
        val openIntent = Intent().apply {
            setClassName(
                applicationContext.packageName,
                "com.myra.assistant.ui.main.MainActivity"
            )
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext, reminderId.toInt(), openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(applicationContext, Constants.NOTIF_CHANNEL_REMINDER)
            .setContentTitle("MYRA reminder")
            .setContentText(title)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        val notificationId = (reminderId % Int.MAX_VALUE).toInt()
        (applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(notificationId, notification)
        Logger.i("ReminderWorker", "Reminder notification posted")
    }
}
