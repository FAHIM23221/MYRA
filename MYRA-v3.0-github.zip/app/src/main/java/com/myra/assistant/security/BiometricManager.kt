package com.myra.assistant.security

import android.content.Context
import androidx.biometric.BiometricManager as AndroidBiometricManager
import androidx.fragment.app.FragmentActivity

/**
 * Small biometric wrapper. Prompt handling lives in [SecurityManager];
 * this object only answers availability and delegates the prompt.
 */
object BiometricManager {

    fun isAvailable(context: Context): Boolean {
        return AndroidBiometricManager.from(context)
            .canAuthenticate(AndroidBiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            AndroidBiometricManager.BIOMETRIC_SUCCESS
    }

    fun showPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        SecurityManager(activity).authenticateWithBiometric(activity, onSuccess, onError)
    }
}
