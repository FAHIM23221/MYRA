package com.myra.assistant.service

/**
 * Voice phrases and announcement text for handling incoming calls hands-free.
 * Bengali + English; matching is case-insensitive and substring-based.
 */
object CallAssistant {

    /** What MYRA says when a call comes in. Names the caller when known. */
    fun announceText(callerName: String?): String {
        val name = callerName?.trim().orEmpty()
        return if (name.isEmpty()) {
            "Incoming call. / একটি কল আসছে।"
        } else {
            "Call aane pe MYRA naam bolegi: $name. " +
                "$name কল করছেন। Incoming call from $name."
        }
    }

    /** "answer" / "উত্তর" / "ধরো" — user wants the call answered by voice. */
    fun shouldAnswerByVoice(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("answer") ||
            lower.contains("উত্তর") ||
            lower.contains("ধরো") ||
            lower.contains("ধরুন") ||
            lower.contains("pick up")
    }

    /** "reject" / "কাটো" / "কেটে দাও" — user wants the call rejected by voice. */
    fun shouldRejectByVoice(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("reject") ||
            lower.contains("কাটো") ||
            lower.contains("কেটে দাও") ||
            lower.contains("decline")
    }
}
