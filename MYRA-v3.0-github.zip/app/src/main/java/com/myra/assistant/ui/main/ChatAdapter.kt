package com.myra.assistant.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.models.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Two view types: MYRA (left) and user (right). */
class ChatAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var items: List<ChatMessage> = emptyList()
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun submitList(list: List<ChatMessage>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int =
        if (items[position].isUser) VIEW_TYPE_USER else VIEW_TYPE_MYRA

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == VIEW_TYPE_USER) {
            UserViewHolder(inflater.inflate(R.layout.item_chat_user, parent, false))
        } else {
            MyraViewHolder(inflater.inflate(R.layout.item_chat_myra, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = items[position]
        when (holder) {
            is UserViewHolder -> holder.bind(message)
            is MyraViewHolder -> holder.bind(message)
        }
    }

    override fun getItemCount(): Int = items.size

    inner class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val messageText: TextView = view.findViewById(R.id.messageText)
        private val timeText: TextView = view.findViewById(R.id.timeText)

        fun bind(message: ChatMessage) {
            messageText.text = message.text
            timeText.text = timeFormat.format(Date(message.timestamp))
        }
    }

    inner class MyraViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val messageText: TextView = view.findViewById(R.id.messageText)
        private val timeText: TextView = view.findViewById(R.id.timeText)

        fun bind(message: ChatMessage) {
            messageText.text = message.text
            timeText.text = timeFormat.format(Date(message.timestamp))
        }
    }

    companion object {
        private const val VIEW_TYPE_USER = 1
        private const val VIEW_TYPE_MYRA = 2
    }
}
