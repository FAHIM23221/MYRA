package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger

/** On boot, restart the voice service if the user enabled background mode. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val backgroundMode = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(Constants.KEY_BACKGROUND_MODE, false)
        if (!backgroundMode) {
            Logger.i("BootReceiver", "Background mode off — not starting voice service")
            return
        }
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, ForegroundVoiceService::class.java)
            )
            Logger.i("BootReceiver", "ForegroundVoiceService started after boot")
        } catch (e: Exception) {
            Logger.e("BootReceiver", "Failed to start voice service after boot", e)
        }
    }
}
