package com.myra.assistant.utils

object Constants {
    const val PREFS_NAME = "myra_prefs"
    const val SECURE_PREFS_NAME = "myra_secure_prefs"
    const val KEY_API_KEY = "gemini_api_key"
    const val KEY_TTS_API_KEY = "tts_api_key"
    const val KEY_USER_NAME = "user_name"
    const val KEY_PRIME_NAME = "prime_name"
    const val KEY_PRIME_NUMBER = "prime_number"
    const val KEY_WAKE_WORD = "wake_word"
    const val KEY_PERSONALITY = "personality"
    const val KEY_VOICE_TYPE = "voice_type"
    const val KEY_LIVE_MODE = "live_mode"
    const val KEY_CALL_ANNOUNCE = "call_announce"
    const val KEY_SPEECH_RATE = "speech_rate"
    const val KEY_LANGUAGE = "language" // "auto" | "bn" | "en"
    const val KEY_BACKGROUND_MODE = "background_mode"
    const val KEY_QUIET_START = "quiet_start_min"
    const val KEY_QUIET_END = "quiet_end_min"
    const val KEY_PROACTIVE_ENABLED = "proactive_enabled"
    const val KEY_GUEST_ALLOWED = "guest_allowed"
    const val KEY_CAMERA_RECOGNITION = "camera_recognition" // presence-only sessions, default off
    const val KEY_SCREEN_UNDERSTANDING = "screen_understanding"
    const val KEY_MEMORY_CONSENT = "memory_consent"
    const val KEY_OWNER_ENROLLED = "owner_enrolled"

    const val GEMINI_WS_BASE =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    const val GEMINI_REST_BASE = "https://generativelanguage.googleapis.com/"
    const val GEMINI_LIVE_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
    const val GEMINI_TEXT_MODEL = "models/gemini-2.5-flash"
    const val GEMINI_VOICE = "Aoede"

    const val NOTIF_CHANNEL_VOICE = "myra_voice_channel"
    const val NOTIF_CHANNEL_OVERLAY = "myra_overlay_channel"
    const val NOTIF_CHANNEL_REMINDER = "myra_reminder_channel"
    const val NOTIF_ID_VOICE = 1001
    const val NOTIF_ID_OVERLAY = 1002
    const val SAMPLE_RATE_IN = 16000
    const val SAMPLE_RATE_OUT = 24000
    const val ACTION_SHOW_OVERLAY = "com.myra.assistant.SHOW_OVERLAY"
    const val ACTION_HIDE_OVERLAY = "com.myra.assistant.HIDE_OVERLAY"
    const val ACTION_START_LISTENING = "com.myra.assistant.START_LISTENING"
    const val ACTION_STOP_LISTENING = "com.myra.assistant.STOP_LISTENING"
}
