package com.myra.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.myra.assistant.models.OrbState
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import java.util.Locale
import java.util.UUID

/**
 * Speech-to-text (SpeechRecognizer) + text-to-speech (TextToSpeech) for MYRA.
 *
 * Does NOT request any permission itself — the caller must hold RECORD_AUDIO
 * before calling [startListening].
 */
class VoiceManager(
    context: Context,
    private val onResult: (String) -> Unit,
    private val onError: (String) -> Unit,
    private val onState: (OrbState) -> Unit
) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak: Pair<String, (() -> Unit)?>? = null
    private var speechRate: Float =
        prefs.getFloat(Constants.KEY_SPEECH_RATE, 1.0f).coerceIn(0.5f, 2.0f)

    @Volatile
    var isListening: Boolean = false
        private set

    init {
        initTts()
    }

    // ------------------------------------------------------------------ STT

    fun startListening() {
        if (isListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            onError("Speech recognition is not available on this device. / এই ডিভাইসে ভয়েস শনাক্তকরণ উপলব্ধ নয়।")
            onState(OrbState.ERROR)
            return
        }
        stopSpeaking()
        val languagePref = prefs.getString(Constants.KEY_LANGUAGE, "auto") ?: "auto"
        val languageTag = if (languagePref == "en") "en-US" else "bn-BD"

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            val sr = SpeechRecognizer.createSpeechRecognizer(appContext).also { recognizer = it }
            sr.setRecognitionListener(recognitionListener)
            sr.startListening(intent)
            isListening = true
            onState(OrbState.LISTENING)
            Logger.d("VoiceManager", "Listening started ($languageTag)")
        } catch (e: SecurityException) {
            Logger.e("VoiceManager", "Missing RECORD_AUDIO permission", e)
            onError("Microphone permission is needed to listen. / শোনার জন্য মাইক্রোফোনের অনুমতি দরকার।")
            onState(OrbState.ERROR)
        } catch (e: Exception) {
            Logger.e("VoiceManager", "Failed to start listening", e)
            onError("Could not start listening. / শোনা শুরু করা যায়নি।")
            onState(OrbState.ERROR)
        }
    }

    fun stopListening() {
        if (!isListening) return
        isListening = false
        try {
            recognizer?.stopListening()
        } catch (e: Exception) {
            Logger.e("VoiceManager", "stopListening failed", e)
        }
        onState(OrbState.IDLE)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            onState(OrbState.LISTENING)
        }

        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() {
            isListening = false
            onState(OrbState.PROCESSING)
        }

        override fun onPartialResults(partialResults: Bundle?) = Unit

        override fun onResults(results: Bundle?) {
            isListening = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                onState(OrbState.PROCESSING)
                onResult(text)
            } else {
                onState(OrbState.IDLE)
                onError("Sorry, I didn't catch that. / দুঃখিত, শুনতে পাইনি।")
            }
        }

        override fun onError(error: Int) {
            isListening = false
            val message = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH ->
                    "Sorry, I didn't catch that. Please try again. / দুঃখিত, শুনতে পাইনি। আবার বলুন।"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Network error — please check your connection. / নেটওয়ার্ক সমস্যা হয়েছে, সংযোগটি দেখুন।"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Microphone permission is needed to listen. / শোনার জন্য মাইক্রোফোনের অনুমতি দরকার।"
                SpeechRecognizer.ERROR_AUDIO ->
                    "Microphone error — please try again. / মাইক্রোফোনে সমস্যা হয়েছে, আবার চেষ্টা করুন।"
                SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    "Voice service is busy — please try again. / ভয়েস সেবা ব্যস্ত আছে, আবার চেষ্টা করুন।"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "I didn't hear anything. / কিছু শুনতে পাইনি।"
                else ->
                    "Something went wrong with listening. / শোনার সময় সমস্যা হয়েছে।"
            }
            Logger.w("VoiceManager", "Recognition error code=$error")
            onState(OrbState.ERROR)
            onError(message)
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    // ------------------------------------------------------------------ TTS

    private fun initTts() {
        tts = TextToSpeech(appContext) { status ->
            if (status != TextToSpeech.SUCCESS) {
                Logger.e("VoiceManager", "TextToSpeech init failed: $status")
                ttsReady = false
                return@TextToSpeech
            }
            val languagePref = prefs.getString(Constants.KEY_LANGUAGE, "auto") ?: "auto"
            val locale = if (languagePref == "bn") Locale("bn", "BD") else Locale.ENGLISH
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Logger.w("VoiceManager", "TTS language $locale not supported, falling back to default")
                tts?.language = Locale.getDefault()
            }
            tts?.setSpeechRate(speechRate)
            tts?.setPitch(1.0f)
            tts?.setOnUtteranceProgressListener(utteranceListener)
            ttsReady = true
            pendingSpeak?.let { (text, done) ->
                pendingSpeak = null
                speak(text, done)
            }
        }
    }

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            onState(OrbState.SPEAKING)
        }

        override fun onDone(utteranceId: String?) {
            pendingDoneCallback?.invoke()
            pendingDoneCallback = null
            onState(OrbState.IDLE)
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            pendingDoneCallback?.invoke()
            pendingDoneCallback = null
            onState(OrbState.IDLE)
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            pendingDoneCallback?.invoke()
            pendingDoneCallback = null
            onState(OrbState.IDLE)
        }
    }

    @Volatile
    private var pendingDoneCallback: (() -> Unit)? = null

    /**
     * Speak [text] aloud. If TTS is not ready yet the utterance is queued and
     * spoken as soon as initialisation finishes. [onDone] runs on completion
     * (or on error) and may be null.
     */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (text.isBlank()) {
            onDone?.invoke()
            return
        }
        val engine = tts
        if (!ttsReady || engine == null) {
            pendingSpeak = text to onDone
            return
        }
        pendingDoneCallback = onDone
        onState(OrbState.SPEAKING)
        val utteranceId = UUID.randomUUID().toString()
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            Logger.e("VoiceManager", "TTS speak failed: $result")
            pendingDoneCallback = null
            onState(OrbState.IDLE)
            onDone?.invoke()
        }
    }

    /** Cancel any in-progress speech immediately (barge-in). */
    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Logger.e("VoiceManager", "stopSpeaking failed", e)
        }
        pendingDoneCallback = null
        pendingSpeak = null
    }

    fun setSpeechRate(rate: Float) {
        speechRate = rate.coerceIn(0.5f, 2.0f)
        prefs.edit().putFloat(Constants.KEY_SPEECH_RATE, speechRate).apply()
        if (ttsReady) tts?.setSpeechRate(speechRate)
    }

    fun destroy() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            Logger.e("VoiceManager", "Recognizer destroy failed", e)
        }
        recognizer = null
        isListening = false
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Logger.e("VoiceManager", "TTS shutdown failed", e)
        }
        tts = null
        ttsReady = false
    }
}
