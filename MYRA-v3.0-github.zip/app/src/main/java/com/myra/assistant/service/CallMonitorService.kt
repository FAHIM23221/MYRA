package com.myra.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import java.util.Locale

/**
 * Announces incoming calls by the caller's name and broadcasts call state.
 *
 * Android 12 (API 31)+ uses [TelephonyCallback] for state changes; the
 * incoming number is captured with a [PhoneStateListener] registered only
 * for that purpose (TelephonyCallback does not expose the number). Below
 * API 31 the PhoneStateListener drives everything.
 *
 * Broadcasts (extra "number" when known):
 * - com.myra.assistant.CALL_RINGING
 * - com.myra.assistant.CALL_ACTIVE
 * - com.myra.assistant.CALL_ENDED
 */
class CallMonitorService : Service() {

    companion object {
        const val ACTION_CALL_RINGING = "com.myra.assistant.CALL_RINGING"
        const val ACTION_CALL_ACTIVE = "com.myra.assistant.CALL_ACTIVE"
        const val ACTION_CALL_ENDED = "com.myra.assistant.CALL_ENDED"
        const val EXTRA_NUMBER = "number"
        const val EXTRA_CALLER_NAME = "caller_name"
    }

    private var telephonyManager: TelephonyManager? = null
    private var telephonyCallback: TelephonyCallback? = null
    private var phoneStateListener: PhoneStateListener? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingAnnouncement: String? = null

    @Volatile
    private var latestIncomingNumber: String? = null

    @Volatile
    private var lastState: Int = TelephonyManager.CALL_STATE_IDLE

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(Constants.NOTIF_ID_VOICE, buildNotification())
        initTts()
        registerCallListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterCallListener()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Logger.e("CallMonitorService", "TTS shutdown failed", e)
        }
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------ telephony

    private fun registerCallListener() {
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return
        telephonyManager = tm
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) {
                    handleCallState(state, latestIncomingNumber)
                }
            }
            telephonyCallback = callback
            try {
                tm.registerTelephonyCallback(
                    androidx.core.content.ContextCompat.getMainExecutor(this),
                    callback
                )
            } catch (e: Exception) {
                Logger.e("CallMonitorService", "registerTelephonyCallback failed", e)
            }
            // Number capture only — state is driven by the callback above.
            val listener = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, incomingNumber: String?) {
                    if (!incomingNumber.isNullOrBlank()) latestIncomingNumber = incomingNumber
                }
            }
            phoneStateListener = listener
            @Suppress("DEPRECATION")
            tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
        } else {
            val listener = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, incomingNumber: String?) {
                    if (!incomingNumber.isNullOrBlank()) latestIncomingNumber = incomingNumber
                    handleCallState(state, incomingNumber)
                }
            }
            phoneStateListener = listener
            @Suppress("DEPRECATION")
            tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
        }
    }

    private fun unregisterCallListener() {
        val tm = telephonyManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (telephonyCallback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            }
        } catch (e: Exception) {
            Logger.e("CallMonitorService", "unregisterTelephonyCallback failed", e)
        }
        try {
            @Suppress("DEPRECATION")
            phoneStateListener?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (e: Exception) {
            Logger.e("CallMonitorService", "PhoneStateListener unregister failed", e)
        }
        telephonyCallback = null
        phoneStateListener = null
    }

    private fun handleCallState(state: Int, incomingNumber: String?) {
        if (state == lastState) return
        lastState = state
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                val number = incomingNumber ?: latestIncomingNumber
                val name = number?.let { resolveCallerName(it) }
                Logger.i("CallMonitorService", "Incoming call ringing")
                sendBroadcast(
                    Intent(ACTION_CALL_RINGING).apply {
                        putExtra(EXTRA_NUMBER, number)
                        putExtra(EXTRA_CALLER_NAME, name)
                    }
                )
                if (isCallAnnounceEnabled()) {
                    announce(CallAssistant.announceText(name ?: number))
                }
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                sendBroadcast(Intent(ACTION_CALL_ACTIVE))
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                latestIncomingNumber = null
                sendBroadcast(Intent(ACTION_CALL_ENDED))
            }
        }
    }

    private fun isCallAnnounceEnabled(): Boolean {
        return getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(Constants.KEY_CALL_ANNOUNCE, false)
    }

    /** Resolve a display name for a number via Contacts (null if unknown). */
    private fun resolveCallerName(number: String): String? {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            val cursor: Cursor? = contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            cursor?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: SecurityException) {
            Logger.e("CallMonitorService", "READ_CONTACTS permission missing", e)
            null
        } catch (e: Exception) {
            Logger.e("CallMonitorService", "Caller lookup failed", e)
            null
        }
    }

    // ------------------------------------------------------------ TTS announce

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status != TextToSpeech.SUCCESS) {
                Logger.e("CallMonitorService", "TTS init failed: $status")
                return@TextToSpeech
            }
            val languagePref = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
                .getString(Constants.KEY_LANGUAGE, "auto") ?: "auto"
            val locale = if (languagePref == "bn") Locale("bn", "BD") else Locale.ENGLISH
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                tts?.language = Locale.getDefault()
            }
            ttsReady = true
            pendingAnnouncement?.let {
                pendingAnnouncement = null
                announce(it)
            }
        }
    }

    private fun announce(text: String) {
        if (!ttsReady || tts == null) {
            pendingAnnouncement = text
            return
        }
        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "call_announce")
        } catch (e: Exception) {
            Logger.e("CallMonitorService", "Announce failed", e)
        }
    }

    // ------------------------------------------------------------ notification

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            Constants.NOTIF_CHANNEL_VOICE,
            "MYRA voice",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "MYRA voice and call announcements" }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent().apply {
            setClassName(packageName, "com.myra.assistant.ui.main.MainActivity")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA")
            .setContentText("Listening for calls — tap to open")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }
}
