package com.myra.assistant.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.myra.assistant.databinding.ActivityCallAssistantBinding
import com.myra.assistant.service.CallAssistant
import java.util.Locale

/**
 * Shown on an incoming call. Answer / reject by button or by voice
 * ("Answer" / "Reject", Bengali or English). All TelecomManager calls are
 * guarded by the ANSWER_PHONE_CALLS permission and try/catch — a missing
 * permission never crashes this screen.
 */
class CallAssistantActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCallAssistantBinding
    private var recognizer: SpeechRecognizer? = null

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceListen() else {
            binding.statusText.text = getString(
                com.myra.assistant.R.string.call_voice_permission_needed
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCallAssistantBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val callerName = intent.getStringExtra(EXTRA_CALLER_NAME)
            ?: intent.getStringExtra(EXTRA_CALLER_NUMBER)
            ?: getString(com.myra.assistant.R.string.caller_unknown)
        binding.callerNameText.text = callerName
        binding.announceText.text = CallAssistant.announceText(callerName)
        binding.hintText.text = getString(com.myra.assistant.R.string.say_answer_reject)

        val canAnswer = hasAnswerPermission()
        binding.answerButton.isEnabled = canAnswer
        binding.rejectButton.isEnabled = canAnswer
        if (!canAnswer) {
            binding.statusText.text = getString(
                com.myra.assistant.R.string.call_permission_missing
            )
        }

        binding.answerButton.setOnClickListener { answerCall() }
        binding.rejectButton.setOnClickListener { rejectCall() }
        binding.voiceListenButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                startVoiceListen()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun hasAnswerPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.ANSWER_PHONE_CALLS
        ) == PackageManager.PERMISSION_GRANTED

    private fun telecomManager(): TelecomManager? =
        getSystemService(TelecomManager::class.java)

    private fun answerCall() {
        if (!hasAnswerPermission()) {
            binding.statusText.text = getString(
                com.myra.assistant.R.string.call_permission_missing
            )
            return
        }
        try {
            telecomManager()?.acceptRingingCall()
            binding.statusText.text = getString(com.myra.assistant.R.string.call_answered)
            Toast.makeText(this, com.myra.assistant.R.string.call_answered, Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: SecurityException) {
            binding.statusText.text = getString(com.myra.assistant.R.string.call_permission_missing)
        } catch (e: Exception) {
            binding.statusText.text = getString(com.myra.assistant.R.string.call_action_failed)
        }
    }

    private fun rejectCall() {
        if (!hasAnswerPermission()) {
            binding.statusText.text = getString(
                com.myra.assistant.R.string.call_permission_missing
            )
            return
        }
        try {
            telecomManager()?.endCall()
            binding.statusText.text = getString(com.myra.assistant.R.string.call_rejected)
            Toast.makeText(this, com.myra.assistant.R.string.call_rejected, Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: SecurityException) {
            binding.statusText.text = getString(com.myra.assistant.R.string.call_permission_missing)
        } catch (e: Exception) {
            binding.statusText.text = getString(com.myra.assistant.R.string.call_action_failed)
        }
    }

    private fun startVoiceListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            binding.statusText.text = getString(com.myra.assistant.R.string.call_voice_unavailable)
            return
        }
        binding.statusText.text = getString(com.myra.assistant.R.string.listening)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onResults(results: Bundle?) {
                val heard = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                binding.statusText.text = heard.ifBlank {
                    getString(com.myra.assistant.R.string.call_voice_unavailable)
                }
                when {
                    CallAssistant.shouldAnswerByVoice(heard) -> answerCall()
                    CallAssistant.shouldRejectByVoice(heard) -> rejectCall()
                    heard.isNotBlank() -> binding.statusText.text =
                        getString(com.myra.assistant.R.string.say_answer_reject)
                }
            }

            override fun onError(error: Int) {
                binding.statusText.text = getString(
                    com.myra.assistant.R.string.call_voice_unavailable
                )
            }
        })
        try {
            sr.startListening(intent)
        } catch (e: Exception) {
            binding.statusText.text = getString(com.myra.assistant.R.string.call_voice_unavailable)
        }
    }

    override fun onDestroy() {
        runCatching { recognizer?.destroy() }
        recognizer = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CALLER_NAME = "caller_name"
        const val EXTRA_CALLER_NUMBER = "caller_number"
    }
}
