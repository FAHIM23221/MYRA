package com.myra.assistant.security

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.MyraApplication
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivitySecuritySettingsBinding

/**
 * App-lock master switches + credential setup.
 * Encryption note is always on: SecurePrefs is EncryptedSharedPreferences
 * (MasterKey AES256_GCM) — "AES-256-GCM (Android Keystore) — Always ON".
 */
class SecuritySettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySecuritySettingsBinding
    private lateinit var securityManager: SecurityManager
    private val securePrefs by lazy { (application as MyraApplication).securePrefs }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecuritySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        securityManager = SecurityManager(this)

        binding.appLockSwitch.isChecked =
            securePrefs.getBoolean(KEY_APP_LOCK_ENABLED, false)
        binding.appLockSwitch.setOnCheckedChangeListener { _, checked ->
            securePrefs.putBoolean(KEY_APP_LOCK_ENABLED, checked)
        }

        binding.fingerprintSwitch.isChecked = securityManager.isBiometricEnabled()
        binding.fingerprintSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked && !BiometricManager.isAvailable(this)) {
                Toast.makeText(this, R.string.biometric_unavailable, Toast.LENGTH_LONG).show()
                binding.fingerprintSwitch.isChecked = false
                return@setOnCheckedChangeListener
            }
            securityManager.setBiometricEnabled(checked)
        }

        binding.deviceLockSwitch.isChecked =
            securePrefs.getBoolean(KEY_DEVICE_SCREEN_LOCK, false)
        binding.deviceLockSwitch.setOnCheckedChangeListener { _, checked ->
            securePrefs.putBoolean(KEY_DEVICE_SCREEN_LOCK, checked)
        }

        binding.privateModeSwitch.isChecked =
            securePrefs.getBoolean(KEY_PRIVATE_MODE, false)
        binding.privateModeSwitch.setOnCheckedChangeListener { _, checked ->
            securePrefs.putBoolean(KEY_PRIVATE_MODE, checked)
        }

        binding.selectAppsButton.setOnClickListener {
            startActivity(Intent(this, AppSelectionActivity::class.java))
        }
        binding.setPinButton.setOnClickListener { showSetPinDialog() }
        binding.setPatternButton.setOnClickListener {
            startActivity(Intent(this, PatternSetupActivity::class.java))
        }
        binding.setVoiceButton.setOnClickListener { showSetVoiceDialog() }
    }

    override fun onResume() {
        super.onResume()
        refreshStatuses()
    }

    private fun refreshStatuses() {
        binding.pinStatusText.text = if (securityManager.hasPin()) {
            getString(R.string.pin_set)
        } else {
            getString(R.string.pin_not_set)
        }
        binding.patternStatusText.text = if (securityManager.hasPattern()) {
            getString(R.string.pattern_set)
        } else {
            getString(R.string.pattern_not_set)
        }
        binding.voiceStatusText.text = if (securityManager.hasVoicePassphrase()) {
            getString(R.string.voice_set)
        } else {
            getString(R.string.voice_not_set)
        }
    }

    private fun showSetPinDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val pinEdit = EditText(this).apply {
            hint = getString(R.string.new_pin)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val confirmEdit = EditText(this).apply {
            hint = getString(R.string.confirm_pin)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        layout.addView(pinEdit)
        layout.addView(confirmEdit)
        AlertDialog.Builder(this)
            .setTitle(R.string.set_pin)
            .setView(layout)
            .setPositiveButton(R.string.save) { _, _ ->
                val pin = pinEdit.text?.toString().orEmpty()
                val confirm = confirmEdit.text?.toString().orEmpty()
                when {
                    pin.length < 4 -> Toast.makeText(
                        this, R.string.pin_too_short, Toast.LENGTH_SHORT
                    ).show()
                    pin != confirm -> Toast.makeText(
                        this, R.string.pin_mismatch, Toast.LENGTH_SHORT
                    ).show()
                    else -> {
                        securityManager.setPin(pin)
                        Toast.makeText(this, R.string.pin_saved, Toast.LENGTH_SHORT).show()
                        refreshStatuses()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSetVoiceDialog() {
        val phraseEdit = EditText(this).apply {
            hint = getString(R.string.voice_passphrase_hint)
            setPadding(48, 24, 48, 0)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.set_voice_passphrase)
            .setMessage(R.string.voice_passphrase_note)
            .setView(phraseEdit)
            .setPositiveButton(R.string.save) { _, _ ->
                val phrase = phraseEdit.text?.toString().orEmpty()
                if (phrase.trim().length < 3) {
                    Toast.makeText(this, R.string.voice_too_short, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                securityManager.setVoicePassphrase(phrase)
                Toast.makeText(this, R.string.voice_saved, Toast.LENGTH_SHORT).show()
                refreshStatuses()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        const val KEY_APP_LOCK_ENABLED = "app_lock_enabled"
        const val KEY_DEVICE_SCREEN_LOCK = "device_screen_lock"
        const val KEY_PRIVATE_MODE = "private_mode"
    }
}
