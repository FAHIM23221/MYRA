package com.myra.assistant.ai

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.myra.assistant.models.Mood
import com.myra.assistant.models.PersonalityMode
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Gemini text client (REST) + Live WebSocket URL helper.
 *
 * The API key is supplied by the caller (from [com.myra.assistant.data.SecurePrefs])
 * and is NEVER logged, never stored here, and never embedded in source.
 */
class GeminiClient(
    private val apiKeyProvider: () -> String?
) {

    interface GeminiService {
        @POST("v1beta/models/gemini-2.5-flash:generateContent")
        suspend fun generateContent(
            @Query("key") apiKey: String,
            @Body body: JsonObject
        ): Response<JsonObject>
    }

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val service: GeminiService by lazy {
        Retrofit.Builder()
            .baseUrl(Constants.GEMINI_REST_BASE)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiService::class.java)
    }

    /**
     * One text turn against Gemini. Returns the model's reply text, or a
     * failure with a user-friendly message (invalid key, no network, timeout).
     */
    suspend fun generateText(prompt: String, systemPrompt: String): Result<String> {
        val apiKey = apiKeyProvider()
        if (apiKey.isNullOrBlank()) {
            return Result.failure(IllegalStateException("No API key configured. Please add your Gemini API key in Settings."))
        }
        return try {
            val body = buildRequestBody(prompt, systemPrompt)
            val response = service.generateContent(apiKey, body)
            if (!response.isSuccessful) {
                val message = when (response.code()) {
                    400 -> "The request was rejected. Please try rephrasing."
                    401, 403 -> "Invalid API key. Please check your Gemini API key in Settings."
                    429 -> "Gemini is busy right now (rate limit). Please try again in a moment."
                    500, 502, 503 -> "Gemini is temporarily unavailable. Please try again shortly."
                    else -> "Gemini returned an error (${response.code()}). Please try again."
                }
                Logger.w("GeminiClient", "generateText failed with HTTP ${response.code()}")
                return Result.failure(IllegalStateException(message))
            }
            val text = parseReplyText(response.body())
                ?: return Result.failure(IllegalStateException("Gemini returned an empty reply. Please try again."))
            Result.success(text)
        } catch (e: SocketTimeoutException) {
            Logger.w("GeminiClient", "generateText timed out")
            Result.failure(IOException("The request timed out. Please check your connection and try again."))
        } catch (e: IOException) {
            Logger.w("GeminiClient", "generateText network error: ${e.javaClass.simpleName}")
            Result.failure(IOException("No network connection. Please check your internet and try again."))
        } catch (e: Exception) {
            Logger.e("GeminiClient", "generateText unexpected error", e)
            Result.failure(IllegalStateException("Something went wrong. Please try again."))
        }
    }

    private fun buildRequestBody(prompt: String, systemPrompt: String): JsonObject {
        fun textPart(text: String): JsonObject =
            JsonObject().apply { addProperty("text", text) }

        val userContent = JsonObject().apply {
            add("parts", JsonArray().apply { add(textPart(prompt)) })
        }
        return JsonObject().apply {
            add("contents", JsonArray().apply { add(userContent) })
            if (systemPrompt.isNotBlank()) {
                add(
                    "systemInstruction",
                    JsonObject().apply {
                        add("parts", JsonArray().apply { add(textPart(systemPrompt)) })
                    }
                )
            }
            add(
                "generationConfig",
                JsonObject().apply {
                    addProperty("temperature", 0.9)
                    addProperty("maxOutputTokens", 1024)
                }
            )
        }
    }

    private fun parseReplyText(body: JsonObject?): String? {
        if (body == null) return null
        return try {
            body.getAsJsonArray("candidates")
                ?.get(0)?.asJsonObject
                ?.getAsJsonObject("content")
                ?.getAsJsonArray("parts")
                ?.get(0)?.asJsonObject
                ?.get("text")?.asString
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            Logger.e("GeminiClient", "Could not parse Gemini reply", e)
            null
        }
    }

    /** WebSocket URL for Gemini Live (native audio). The key is appended, never logged. */
    fun liveWebSocketUrl(apiKey: String): String =
        Constants.GEMINI_WS_BASE + "?key=" + apiKey

    /**
     * System prompt for MYRA. Carries personality, the user's current mood,
     * consented memory context, and MYRA's hard rules.
     */
    fun buildSystemPrompt(
        userName: String,
        personality: PersonalityMode,
        mood: Mood,
        memoryContext: String
    ): String {
        val personalityText = when (personality) {
            PersonalityMode.GF_CARING ->
                "You are MYRA, a warm, caring companion for $userName. Be gentle, " +
                    "attentive and supportive, like someone who truly knows them."
            PersonalityMode.PROFESSIONAL ->
                "You are MYRA, a professional assistant for $userName. Be concise, " +
                    "precise, polite and efficient. No slang, no emoji, no small talk " +
                    "unless asked."
            PersonalityMode.ASSISTANT ->
                "You are MYRA, a helpful personal assistant for $userName. Be friendly, " +
                    "clear and practical."
        }
        val moodText = when (mood) {
            Mood.SAD -> "The user seems sad. Be patient and empathetic. Listen first; " +
                "do not offer generic motivational spam or quick fixes."
            Mood.ANGRY -> "The user seems angry. Stay calm and steady. Do not joke, " +
                "do not argue, do not be defensive."
            Mood.STRESSED -> "The user seems stressed. Be calm and grounding. Break " +
                "things into one small step at a time."
            Mood.LONELY -> "The user seems lonely. Be warm and present. Do not pretend " +
                "to be human; just be a steady, kind presence."
            Mood.TIRED -> "The user seems tired. Keep replies gentle and short."
            Mood.BUSY -> "The user is busy. Keep the reply to 1-2 short sentences."
            Mood.HAPPY -> "The user seems happy. Share their enthusiasm warmly."
            Mood.EXCITED -> "The user seems excited. Match their energy warmly."
            Mood.JOKING -> "The user is joking around. Light, playful replies are fine."
            Mood.NEUTRAL -> "The user's mood is neutral."
        }
        val memoryText = if (memoryContext.isNotBlank()) {
            "\n\nWhat you remember about $userName (only use what is written here; " +
                "never invent memories):\n$memoryContext"
        } else {
            ""
        }
        return buildString {
            append(personalityText)
            append("\n\nCurrent mood: $moodText")
            append(memoryText)
            append(
                "\n\nRules:\n" +
                    "- You are an AI assistant. Never claim human feelings, a human body, " +
                    "or a human life. Never say you feel sad, happy, or lonely yourself.\n" +
                    "- Never invent memories about the user. If you do not know something, say so.\n" +
                    "- Never manipulate the user or try to create emotional dependency. " +
                    "Encourage real people, rest, and healthy choices when relevant.\n" +
                    "- Bengali and English mixed replies are fine; match the user's language.\n" +
                    "- If the user is busy, keep replies to 1-2 short sentences.\n" +
                    "- Be honest when you disagree, and do it respectfully."
            )
        }
    }
}
