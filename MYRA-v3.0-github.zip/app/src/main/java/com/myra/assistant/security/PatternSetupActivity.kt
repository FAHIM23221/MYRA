package com.myra.assistant.security

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivityPatternSetupBinding

/**
 * Set a pattern lock: draw the 3x3 pattern twice. The two draws must match;
 * only then is the pattern saved (salted hash) via SecurityManager.
 */
class PatternSetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPatternSetupBinding
    private lateinit var securityManager: SecurityManager

    private val currentSelection = mutableListOf<Int>()
    private var firstPattern: List<Int>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPatternSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        securityManager = SecurityManager(this)

        val buttons = listOf(
            binding.setupButton0, binding.setupButton1, binding.setupButton2,
            binding.setupButton3, binding.setupButton4, binding.setupButton5,
            binding.setupButton6, binding.setupButton7, binding.setupButton8
        )
        buttons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (index !in currentSelection) {
                    currentSelection.add(index)
                    button.alpha = 0.45f
                    renderStatus()
                }
            }
        }
        binding.setupClearButton.setOnClickListener { clearSelection() }
        binding.setupCancelButton.setOnClickListener { finish() }
        binding.setupConfirmButton.setOnClickListener { confirmDraw() }

        binding.setupStatusText.text = getString(R.string.pattern_draw_first)
    }

    private fun renderStatus() {
        binding.setupStatusText.text = if (currentSelection.isEmpty()) {
            if (firstPattern == null) getString(R.string.pattern_draw_first)
            else getString(R.string.pattern_draw_again)
        } else {
            currentSelection.joinToString(" → ") { (it + 1).toString() }
        }
    }

    private fun clearSelection() {
        currentSelection.clear()
        listOf(
            binding.setupButton0, binding.setupButton1, binding.setupButton2,
            binding.setupButton3, binding.setupButton4, binding.setupButton5,
            binding.setupButton6, binding.setupButton7, binding.setupButton8
        ).forEach { it.alpha = 1f }
        renderStatus()
    }

    private fun confirmDraw() {
        if (currentSelection.size < 4) {
            binding.setupStatusText.text = getString(R.string.pattern_too_short)
            return
        }
        val first = firstPattern
        if (first == null) {
            firstPattern = currentSelection.toList()
            clearSelection()
            binding.setupStatusText.text = getString(R.string.pattern_draw_again)
            return
        }
        if (first == currentSelection) {
            securityManager.setPattern(currentSelection.joinToString(","))
            Toast.makeText(this, R.string.pattern_saved, Toast.LENGTH_SHORT).show()
            finish()
        } else {
            firstPattern = null
            clearSelection()
            binding.setupStatusText.text = getString(R.string.pattern_mismatch)
            Toast.makeText(this, R.string.pattern_mismatch, Toast.LENGTH_SHORT).show()
        }
    }
}
