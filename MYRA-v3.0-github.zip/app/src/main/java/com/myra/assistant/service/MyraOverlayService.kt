package com.myra.assistant.service

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger

/**
 * Small floating "MYRA" orb. Tapping it broadcasts ACTION_START_LISTENING.
 * Requires SYSTEM_ALERT_WINDOW — if the overlay permission is not granted
 * the service stops itself instead of crashing.
 */
class MyraOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var orbView: View? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            Logger.w("MyraOverlayService", "Overlay permission not granted — stopping")
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val orb = TextView(this).apply {
            text = "MYRA"
            setTextColor(0xFFFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
            val sizePx = (56 * resources.displayMetrics.density).toInt()
            val padding = (8 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
            minimumWidth = sizePx
            minimumHeight = sizePx
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF7C4DFF.toInt())
            }
            setOnClickListener {
                sendBroadcast(Intent(Constants.ACTION_START_LISTENING))
            }
        }
        orbView = orb

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = (200 * resources.displayMetrics.density).toInt()
        }
        try {
            windowManager?.addView(orb, params)
        } catch (e: Exception) {
            Logger.e("MyraOverlayService", "Failed to add overlay view", e)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == Constants.ACTION_HIDE_OVERLAY) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            orbView?.let { windowManager?.removeView(it) }
        } catch (e: Exception) {
            Logger.e("MyraOverlayService", "Failed to remove overlay view", e)
        }
        orbView = null
        windowManager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        /** Plain startService: this service never promotes itself to foreground. */
        fun start(context: android.content.Context) {
            context.startService(Intent(context, MyraOverlayService::class.java))
        }
    }
}
