package com.myra.assistant.models

/** Emotional states MYRA can recognise from text + context. Never a diagnosis. */
enum class Mood {
    HAPPY, SAD, ANGRY, STRESSED, LONELY, TIRED, EXCITED, BUSY, NEUTRAL, JOKING
}

enum class PersonalityMode { GF_CARING, PROFESSIONAL, ASSISTANT }

enum class SessionRole { OWNER, CONTACT, GUEST }

enum class OrbState {
    IDLE, LISTENING, PROCESSING, SPEAKING, THINKING,
    EMOTIONAL, CONNECTING, DISCONNECTED, ERROR
}

enum class CommandType {
    OPEN_APP, CALL, WHATSAPP_CALL, SMS, PLAY_MUSIC, SPOTIFY_PLAY,
    FLASHLIGHT_ON, FLASHLIGHT_OFF, VOLUME_UP, VOLUME_DOWN, SEARCH,
    SET_ALARM, SET_REMINDER, CREATE_NOTE, LOOK_AT_SCREEN, EXPLAIN_SCREEN,
    READ_SCREEN, FIND_ON_SCREEN, UNKNOWN
}

data class ChatMessage(
    val id: Long = 0,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val role: SessionRole = SessionRole.OWNER,
    val mood: Mood? = null
)

data class VoiceCommand(
    val rawText: String,
    val type: CommandType,
    val arg: String? = null,
    val arg2: String? = null
)

data class ScreenElement(
    val text: String,
    val contentDescription: String?,
    val className: String?,
    val isClickable: Boolean,
    val bounds: android.graphics.Rect?
)

data class ContactProfile(
    val id: Long = 0,
    val name: String,               // ONLY user-provided, never guessed from a photo
    val relationship: String,
    val preferredAddress: String,
    val notes: String = "",
    val phoneNumber: String? = null,
    val enrolledByOwner: Boolean = true,
    val facePresentInPhoto: Boolean = false // presence-only flag, NO template/embedding stored
)
