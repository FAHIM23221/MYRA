package com.myra.assistant.ui.main

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.myra.assistant.MyraApplication
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivityMainBinding
import com.myra.assistant.models.OrbState
import com.myra.assistant.models.SessionRole
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.memory.MemoryActivity
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.utils.Constants
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels {
        ViewModelProvider.AndroidViewModelFactory.getInstance(application)
    }
    private lateinit var chatAdapter: ChatAdapter

    private var pendingAssistListen = false
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val clockRunnable = object : Runnable {
        override fun run() {
            binding.clockText.text = clockFormat.format(Date())
            clockHandler.postDelayed(this, 1000)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            binding.batteryText.text = if (level >= 0 && scale > 0) {
                "${level * 100 / scale}%"
            } else {
                getString(R.string.battery_unknown)
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val denied = results.filterValues { !it }.keys
        if (denied.isNotEmpty()) {
            binding.statusText.text = getString(R.string.permission_denied)
            Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
        } else if (pendingAssistListen) {
            pendingAssistListen = false
            viewModel.onMicTapped()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        chatAdapter = ChatAdapter()
        binding.chatRecycler.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = chatAdapter
        }

        viewModel.messages.observe(this) { messages ->
            chatAdapter.submitList(messages)
            if (messages.isNotEmpty()) {
                binding.chatRecycler.scrollToPosition(messages.size - 1)
            }
        }
        viewModel.orbState.observe(this) { state ->
            binding.orbView.state = state
            binding.statusText.text = statusTextFor(state)
        }
        viewModel.error.observe(this) { error ->
            if (!error.isNullOrBlank()) {
                binding.statusText.text = error
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                viewModel.clearError()
            }
        }
        viewModel.sessionRole.observe(this) { role ->
            when (role) {
                SessionRole.GUEST -> {
                    binding.guestIndicator.visibility = android.view.View.VISIBLE
                    binding.guestIndicator.text = getString(R.string.guest_mode)
                }
                SessionRole.CONTACT -> {
                    binding.guestIndicator.visibility = android.view.View.VISIBLE
                    binding.guestIndicator.text = getString(R.string.contact_mode)
                }
                else -> binding.guestIndicator.visibility = android.view.View.GONE
            }
        }

        binding.micButton.setOnClickListener { viewModel.onMicTapped() }
        binding.micButton.setOnLongClickListener {
            viewModel.bargeIn()
            Toast.makeText(this, R.string.barge_in_stopped, Toast.LENGTH_SHORT).show()
            true
        }
        binding.sendButton.setOnClickListener { submitText() }
        binding.inputEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitText()
                true
            } else false
        }
        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.memoryButton.setOnClickListener {
            startActivity(Intent(this, MemoryActivity::class.java))
        }

        requestPermissionsIfNeeded()
        startBackgroundServiceIfEnabled()

        if (Intent.ACTION_ASSIST == intent?.action) {
            handleAssistIntent()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (Intent.ACTION_ASSIST == intent.action) {
            handleAssistIntent()
        }
    }

    override fun onStart() {
        super.onStart()
        // Android 14+ (targetSdk 35): the 2-arg registerReceiver() throws
        // SecurityException without an export flag.
        ContextCompat.registerReceiver(
            this,
            batteryReceiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        clockHandler.post(clockRunnable)
    }

    override fun onStop() {
        super.onStop()
        runCatching { unregisterReceiver(batteryReceiver) }
        clockHandler.removeCallbacks(clockRunnable)
    }

    private fun submitText() {
        val text = binding.inputEditText.text?.toString().orEmpty()
        if (text.isBlank()) return
        viewModel.onTextSubmitted(text)
        binding.inputEditText.text?.clear()
    }

    private fun handleAssistIntent() {
        if (hasAllPermissions()) {
            viewModel.onMicTapped()
        } else {
            pendingAssistListen = true
            requestPermissionsIfNeeded()
        }
    }

    private fun hasAllPermissions(): Boolean =
        REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestPermissionsIfNeeded() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) return
        if (missing.contains(Manifest.permission.RECORD_AUDIO) &&
            shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)
        ) {
            AlertDialog.Builder(this)
                .setTitle(R.string.permission_title)
                .setMessage(R.string.permission_rationale)
                .setPositiveButton(R.string.ok) { _, _ ->
                    permissionLauncher.launch(REQUIRED_PERMISSIONS)
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        } else {
            permissionLauncher.launch(REQUIRED_PERMISSIONS)
        }
    }

    private fun startBackgroundServiceIfEnabled() {
        val app = application as MyraApplication
        if (app.securePrefs.getBoolean(Constants.KEY_BACKGROUND_MODE, false)) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, ForegroundVoiceService::class.java)
            )
        }
    }

    private fun statusTextFor(state: OrbState): String = when (state) {
        OrbState.IDLE -> getString(R.string.status_ready)
        OrbState.LISTENING -> getString(R.string.status_listening)
        OrbState.PROCESSING -> getString(R.string.status_processing)
        OrbState.SPEAKING -> getString(R.string.status_speaking)
        OrbState.THINKING -> getString(R.string.status_thinking)
        OrbState.EMOTIONAL -> getString(R.string.status_emotional)
        OrbState.CONNECTING -> getString(R.string.status_connecting)
        OrbState.DISCONNECTED -> getString(R.string.status_disconnected)
        OrbState.ERROR -> getString(R.string.status_error)
    }

    companion object {
        private val REQUIRED_PERMISSIONS: Array<String> = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.SEND_SMS)
            add(Manifest.permission.CAMERA)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
    }
}
