package com.myra.assistant.ui.memory

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.MyraApplication
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivityContactProfileBinding
import com.myra.assistant.models.ContactProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Detail / edit screen for one enrolled contact.
 *
 * Recognition is by the name the owner typed + the owner's confirmation —
 * never by face. The face flag only records whether a face was present in
 * an owner-supplied photo; it is shown here, never used to identify anyone.
 */
class ContactProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityContactProfileBinding
    private val repository by lazy { (application as MyraApplication).repository }

    private var contactId: Long = 0L
    private var facePresentInPhoto: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        contactId = intent.getLongExtra(EXTRA_CONTACT_ID, 0L)
        facePresentInPhoto = intent.getBooleanExtra(EXTRA_FACE_PRESENT, false)

        binding.nameEdit.setText(intent.getStringExtra(EXTRA_NAME).orEmpty())
        binding.relationshipEdit.setText(intent.getStringExtra(EXTRA_RELATIONSHIP).orEmpty())
        binding.preferredAddressEdit.setText(intent.getStringExtra(EXTRA_ADDRESS).orEmpty())
        binding.notesEdit.setText(intent.getStringExtra(EXTRA_NOTES).orEmpty())
        binding.phoneEdit.setText(intent.getStringExtra(EXTRA_PHONE).orEmpty())
        binding.faceFlagText.text = if (facePresentInPhoto) {
            getString(R.string.face_present)
        } else {
            getString(R.string.face_not_checked)
        }
        binding.deleteButton.isEnabled = contactId != 0L

        binding.saveButton.setOnClickListener { save() }
        binding.deleteButton.setOnClickListener { confirmDelete() }
    }

    private fun currentProfile(): ContactProfile? {
        val name = binding.nameEdit.text?.toString().orEmpty().trim()
        if (name.isBlank()) {
            Toast.makeText(this, R.string.contact_name_required, Toast.LENGTH_SHORT).show()
            return null
        }
        return ContactProfile(
            id = contactId,
            name = name,
            relationship = binding.relationshipEdit.text?.toString().orEmpty().trim(),
            preferredAddress = binding.preferredAddressEdit.text?.toString().orEmpty().trim(),
            notes = binding.notesEdit.text?.toString().orEmpty().trim(),
            phoneNumber = binding.phoneEdit.text?.toString().orEmpty().trim().ifEmpty { null },
            enrolledByOwner = true,
            facePresentInPhoto = facePresentInPhoto
        )
    }

    private fun save() {
        val profile = currentProfile() ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { repository.saveContact(profile) }
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@ContactProfileActivity, R.string.contact_saved, Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_contact_title)
            .setMessage(R.string.delete_contact_message)
            .setPositiveButton(R.string.delete) { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    runCatching { repository.deleteContact(contactId) }
                    withContext(Dispatchers.Main) { finish() }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        const val EXTRA_CONTACT_ID = "contact_id"
        const val EXTRA_NAME = "name"
        const val EXTRA_RELATIONSHIP = "relationship"
        const val EXTRA_ADDRESS = "preferredAddress"
        const val EXTRA_NOTES = "notes"
        const val EXTRA_PHONE = "phone"
        const val EXTRA_FACE_PRESENT = "face_present"
    }
}
