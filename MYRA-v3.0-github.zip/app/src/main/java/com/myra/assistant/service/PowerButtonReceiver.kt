package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger

/**
 * Double-press of the power button (two SCREEN_OFF events within 600 ms)
 * opens MYRA and starts listening.
 *
 * NOTE: starting an activity from the background is restricted on Android 10+
 * and may be blocked by the system; the intent is still sent so it works
 * wherever the platform allows it (e.g. while the app is in the foreground
 * or the device is unlocked).
 */
class PowerButtonReceiver : BroadcastReceiver() {

    companion object {
        private const val DOUBLE_PRESS_WINDOW_MS = 600L

        @Volatile
        private var lastScreenOffTime = 0L
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_SCREEN_OFF) return
        val now = System.currentTimeMillis()
        val previous = lastScreenOffTime
        lastScreenOffTime = now
        if (previous != 0L && now - previous <= DOUBLE_PRESS_WINDOW_MS) {
            lastScreenOffTime = 0L
            Logger.i("PowerButtonReceiver", "Double power press — opening MYRA listening")
            try {
                val launch = Intent().apply {
                    setClassName(
                        context.packageName,
                        "com.myra.assistant.ui.main.MainActivity"
                    )
                    action = Constants.ACTION_START_LISTENING
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                context.startActivity(launch)
            } catch (e: Exception) {
                Logger.e("PowerButtonReceiver", "Failed to launch MainActivity", e)
            }
        }
    }
}
