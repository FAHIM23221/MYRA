package com.myra.assistant.automation

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager
import com.myra.assistant.utils.Logger
import java.io.File

/**
 * Executes on-device actions requested by voice commands.
 *
 * Every function returns true only when the action was actually started or
 * confirmed; a failure (no matching app, missing permission, no camera)
 * returns false and is logged. Nothing here claims success without evidence.
 *
 * The caller is responsible for holding the runtime permissions each action
 * needs (CALL_PHONE, SEND_SMS, READ_CONTACTS, CAMERA).
 */
class DeviceController(private val context: Context) {

    private val appContext = context.applicationContext
    private val packageManager: PackageManager = appContext.packageManager

    // ------------------------------------------------------------ apps

    /** Launch the best-matching installed launchable app by (fuzzy) name. */
    fun openApp(name: String): Boolean {
        val query = name.trim().lowercase()
        if (query.isEmpty()) return false
        val candidates = getLaunchableApps()
        // Exact / prefix match first, then substring, then best word overlap.
        val match = candidates.firstOrNull { it.label.lowercase() == query }
            ?: candidates.firstOrNull { it.label.lowercase().startsWith(query) }
            ?: candidates.firstOrNull { it.label.lowercase().contains(query) }
            ?: candidates.firstOrNull { it.packageName.lowercase().contains(query) }
            ?: candidates.maxByOrNull { scoreMatch(it.label.lowercase(), query) }
                ?.takeIf { scoreMatch(it.label.lowercase(), query) > 0 }
            ?: return false
        return try {
            val launch = packageManager.getLaunchIntentForPackage(match.packageName)
                ?: return false
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(launch)
            Logger.i("DeviceController", "Opened app: ${match.label}")
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Failed to open app $query", e)
            false
        }
    }

    fun getInstalledAppNames(): List<String> =
        getLaunchableApps().map { it.label }.sorted()

    private data class LaunchableApp(val label: String, val packageName: String)

    private fun getLaunchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            packageManager.queryIntentActivities(intent, 0).mapNotNull { info ->
                val label = info.loadLabel(packageManager)?.toString() ?: return@mapNotNull null
                LaunchableApp(label, info.activityInfo.packageName)
            }
        } catch (e: Exception) {
            Logger.e("DeviceController", "Failed to list apps", e)
            emptyList()
        }
    }

    private fun scoreMatch(label: String, query: String): Int {
        val labelWords = label.split(Regex("[\\s._-]+"))
        val queryWords = query.split(Regex("[\\s._-]+"))
        return queryWords.count { q -> labelWords.any { w -> w.startsWith(q) || w.contains(q) } }
    }

    // ------------------------------------------------------------ audio

    fun setVolumeUp(): Boolean = adjustVolume(AudioManager.ADJUST_RAISE)

    fun setVolumeDown(): Boolean = adjustVolume(AudioManager.ADJUST_LOWER)

    private fun adjustVolume(direction: Int): Boolean {
        return try {
            val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Volume adjust failed", e)
            false
        }
    }

    // ------------------------------------------------------------ flashlight

    fun toggleFlashlight(on: Boolean): Boolean {
        return try {
            val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cameraManager.setTorchMode(cameraId, on)
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Flashlight toggle failed", e)
            false
        }
    }

    // ------------------------------------------------------------ calls & SMS

    /**
     * Place a call to a phone number, or to a contact resolved by name.
     * Caller must hold CALL_PHONE.
     */
    fun makeCall(numberOrName: String): Boolean {
        val input = numberOrName.trim()
        if (input.isEmpty()) return false
        val number = if (isPhoneNumber(input)) input else resolveContactNumber(input) ?: return false
        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(packageManager) == null) return false
            appContext.startActivity(intent)
            true
        } catch (e: SecurityException) {
            Logger.e("DeviceController", "CALL_PHONE permission missing", e)
            false
        } catch (e: Exception) {
            Logger.e("DeviceController", "Call failed", e)
            false
        }
    }

    /** Send an SMS to a number or a contact resolved by name. Caller must hold SEND_SMS. */
    fun sendSms(nameOrNumber: String, message: String): Boolean {
        val input = nameOrNumber.trim()
        if (input.isEmpty() || message.isBlank()) return false
        val number = if (isPhoneNumber(input)) input else resolveContactNumber(input) ?: return false
        return try {
            SmsManager.getDefault().sendTextMessage(number, null, message, null, null)
            Logger.i("DeviceController", "SMS sent")
            true
        } catch (e: SecurityException) {
            Logger.e("DeviceController", "SEND_SMS permission missing", e)
            false
        } catch (e: Exception) {
            Logger.e("DeviceController", "SMS failed", e)
            false
        }
    }

    private fun isPhoneNumber(input: String): Boolean {
        val digits = input.filter { it.isDigit() }
        return digits.length >= 7 && input.all { it.isDigit() || it in "+*# -()" }
    }

    /** Look up a contact's phone number by display name (fuzzy, first match). */
    private fun resolveContactNumber(name: String): String? {
        return try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            )
            val cursor = appContext.contentResolver.query(
                uri, projection,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null
            ) ?: return null
            cursor.use {
                if (it.moveToFirst()) {
                    it.getString(0)?.takeIf { num -> num.isNotBlank() }
                } else null
            }
        } catch (e: SecurityException) {
            Logger.e("DeviceController", "READ_CONTACTS permission missing", e)
            null
        } catch (e: Exception) {
            Logger.e("DeviceController", "Contact lookup failed", e)
            null
        }
    }

    // ------------------------------------------------------------ system intents

    fun setAlarm(hour: Int, minute: Int, label: String): Boolean {
        if (hour !in 0..23 || minute !in 0..59) return false
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            if (intent.resolveActivity(packageManager) == null) return false
            appContext.startActivity(intent)
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Set alarm failed", e)
            false
        }
    }

    /**
     * Save a note locally (appended to a private notes file) and offer it to
     * the user's notes app via a share sheet. Returns true only if the local
     * save succeeded.
     */
    fun createNote(text: String): Boolean {
        if (text.isBlank()) return false
        val saved = try {
            File(appContext.filesDir, "myra_notes.txt").appendText(
                "${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                    .format(java.util.Date())} — $text\n"
            )
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Failed to save note", e)
            false
        }
        // Best-effort share to a notes app; failure here does not undo the save.
        try {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(share, "Save note with").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (share.resolveActivity(packageManager) != null) {
                appContext.startActivity(chooser)
            }
        } catch (e: Exception) {
            Logger.e("DeviceController", "Note share failed", e)
        }
        return saved
    }

    fun searchWeb(query: String): Boolean {
        if (query.isBlank()) return false
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            if (intent.resolveActivity(packageManager) == null) return false
            appContext.startActivity(intent)
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Web search failed", e)
            false
        }
    }

    fun openGallery(): Boolean {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            if (intent.resolveActivity(packageManager) == null) return false
            appContext.startActivity(intent)
            true
        } catch (e: Exception) {
            Logger.e("DeviceController", "Open gallery failed", e)
            false
        }
    }
}
