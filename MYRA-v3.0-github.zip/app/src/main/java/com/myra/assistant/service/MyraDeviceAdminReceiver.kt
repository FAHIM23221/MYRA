package com.myra.assistant.service

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import com.myra.assistant.utils.Logger

/** Device-admin receiver. Logs enable/disable events only; no policy actions. */
class MyraDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Logger.i("MyraDeviceAdmin", "Device admin enabled")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Logger.i("MyraDeviceAdmin", "Device admin disabled")
    }
}
