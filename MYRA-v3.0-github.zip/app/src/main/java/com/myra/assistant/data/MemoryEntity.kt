package com.myra.assistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A durable fact MYRA remembers about the owner. Stored only with explicit consent. */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val category: String = "general",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val sourceConsent: Boolean = true
)

/**
 * A person the owner enrolled. `facePresentInPhoto` is a presence-only flag:
 * it records only whether a face was present in a photo the owner supplied.
 * No face embedding, template, or biometric identifier is ever stored.
 */
@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val relationship: String = "",
    val preferredAddress: String = "",
    val notes: String = "",
    val phoneNumber: String? = null,
    val enrolledByOwner: Boolean = true,
    val facePresentInPhoto: Boolean = false
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerAtMillis: Long,
    val repeatDaily: Boolean = false,
    val done: Boolean = false,
    val quietRespect: Boolean = true
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val triggerPhrase: String,
    val actionJson: String,
    val enabled: Boolean = true
)

/** One turn of a conversation. Stored only with memory consent and only for the owner. */
@Entity(tableName = "turns")
data class TurnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String = "OWNER",
    val text: String,
    val isUser: Boolean,
    val mood: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
