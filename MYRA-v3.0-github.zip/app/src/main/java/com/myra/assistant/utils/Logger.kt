package com.myra.assistant.utils

import android.util.Log

/** Central logger. NEVER log API keys, PINs, passphrases, contacts or message content. */
object Logger {
    private const val TAG = "MYRA"
    fun d(tag: String, msg: String) { Log.d(TAG, "[$tag] $msg") }
    fun i(tag: String, msg: String) { Log.i(TAG, "[$tag] $msg") }
    fun w(tag: String, msg: String) { Log.w(TAG, "[$tag] $msg") }
    fun e(tag: String, msg: String, t: Throwable? = null) { Log.e(TAG, "[$tag] $msg", t) }

    /** Redact anything that looks like a credential before it can reach a log. */
    fun redact(value: String?): String {
        if (value.isNullOrBlank()) return "<empty>"
        return if (value.length > 8) value.take(4) + "****" else "****"
    }
}
