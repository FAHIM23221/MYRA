package com.myra.assistant.ui.main

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import com.myra.assistant.models.OrbState
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Custom animated orb.
 *
 * `state` and `amplitude` are Kotlin vars; their generated setters ARE the
 * setState(OrbState) / setAmplitude(Float) entry points (a Kotlin var's setter
 * is the setXxx method on the JVM, so an explicit fun setState would clash).
 * Amplitude is the live voice level, 0..1.
 */
class OrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var state: OrbState = OrbState.IDLE
        set(value) {
            field = value
            invalidate()
        }

    var amplitude: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.WHITE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val startTime = SystemClock.uptimeMillis()

    private fun colorFor(state: OrbState): Int = when (state) {
        OrbState.IDLE -> Color.parseColor("#7C4DFF")
        OrbState.LISTENING -> Color.parseColor("#00E5FF")
        OrbState.PROCESSING -> Color.parseColor("#FFC107")
        OrbState.SPEAKING -> Color.parseColor("#00E676")
        OrbState.THINKING -> Color.parseColor("#9D4EDD")
        OrbState.EMOTIONAL -> Color.parseColor("#E91E8C")
        OrbState.CONNECTING -> Color.parseColor("#2196F3")
        OrbState.DISCONNECTED -> Color.parseColor("#9E9E9E")
        OrbState.ERROR -> Color.parseColor("#F44336")
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val elapsed = (SystemClock.uptimeMillis() - startTime) / 1000f
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = min(width, height) * 0.30f

        val pulse = when (state) {
            OrbState.THINKING -> sin(elapsed * 5f) * 0.10f
            OrbState.LISTENING, OrbState.SPEAKING -> sin(elapsed * 6f) * 0.06f
            OrbState.PROCESSING -> sin(elapsed * 8f) * 0.05f
            else -> sin(elapsed * 2f) * 0.03f
        }
        val radius = (baseRadius * (1f + amplitude * 0.4f + pulse)).coerceAtLeast(8f)
        val color = colorFor(state)

        // CONNECTING blinks; every other state is steady.
        val alpha = if (state == OrbState.CONNECTING) {
            (128 + 127 * sin(elapsed * 6f)).toInt().coerceIn(40, 255)
        } else {
            255
        }
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)

        // Outer glow.
        glowPaint.shader = RadialGradient(
            cx, cy, radius * 2.2f,
            Color.argb(90, r, g, b), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius * 2.2f, glowPaint)

        // Core: bright centre fading to a darker edge.
        fillPaint.shader = RadialGradient(
            cx, cy, radius,
            Color.argb(alpha, r, g, b),
            Color.argb(alpha, (r * 0.55f).toInt(), (g * 0.55f).toInt(), (b * 0.55f).toInt()),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, fillPaint)
        fillPaint.shader = null

        // Thin ring.
        ringPaint.alpha = (alpha * 0.6f).toInt()
        canvas.drawCircle(cx, cy, radius, ringPaint)

        // Soft highlight, top-left.
        highlightPaint.color = Color.WHITE
        highlightPaint.alpha = 70
        canvas.drawCircle(cx - radius * 0.3f, cy - radius * 0.35f, radius * 0.28f, highlightPaint)

        // 3 orbiting dots.
        val orbitRadius = radius * 1.55f
        val speed = if (state == OrbState.IDLE) 0.5f else 1.4f
        for (i in 0 until 3) {
            val angle = elapsed * speed + i * (2f * Math.PI.toFloat() / 3f)
            val dx = cx + cos(angle) * orbitRadius
            val dy = cy + sin(angle) * orbitRadius
            dotPaint.color = Color.WHITE
            dotPaint.alpha = 220
            canvas.drawCircle(dx, dy, radius * 0.10f + 3f, dotPaint)
        }

        // Keep the animation running.
        postInvalidateOnAnimation()
    }
}
