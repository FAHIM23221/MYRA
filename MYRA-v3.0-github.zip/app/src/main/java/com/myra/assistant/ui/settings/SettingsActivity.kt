package com.myra.assistant.ui.settings

import android.app.TimePickerDialog
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.myra.assistant.MyraApplication
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivitySettingsBinding
import com.myra.assistant.models.PersonalityMode
import com.myra.assistant.security.SecuritySettingsActivity
import com.myra.assistant.ui.memory.MemoryActivity
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Every control reads/writes real prefs through SecurePrefs.
 *
 * NOTE on speech rate: VoiceManager reads it as a Float from the plain
 * SharedPreferences file (Constants.PREFS_NAME), so this screen stores it
 * there with putFloat — SecurePrefs has no float API.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val securePrefs by lazy { (application as MyraApplication).securePrefs }
    private val repository by lazy { (application as MyraApplication).repository }

    private val languageValues = arrayOf("auto", "bn", "en")

    private var quietStartMin: Int = 23 * 60
    private var quietEndMin: Int = 7 * 60

    private val assistantRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        Toast.makeText(this, R.string.default_assistant_done, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupLanguageSpinner()
        setupSpeechRateSeekBar()
        loadAll()

        binding.quietStartButton.setOnClickListener {
            showTimePicker(quietStartMin) { minutes ->
                quietStartMin = minutes
                securePrefs.putInt(Constants.KEY_QUIET_START, minutes)
                binding.quietStartButton.text = formatMinutes(minutes)
            }
        }
        binding.quietEndButton.setOnClickListener {
            showTimePicker(quietEndMin) { minutes ->
                quietEndMin = minutes
                securePrefs.putInt(Constants.KEY_QUIET_END, minutes)
                binding.quietEndButton.text = formatMinutes(minutes)
            }
        }

        binding.saveButton.setOnClickListener { saveAll() }
        binding.memoryButton.setOnClickListener {
            startActivity(Intent(this, MemoryActivity::class.java))
        }
        binding.securityButton.setOnClickListener {
            startActivity(Intent(this, SecuritySettingsActivity::class.java))
        }
        binding.defaultAssistantButton.setOnClickListener { requestDefaultAssistant() }
        binding.deleteMemoriesButton.setOnClickListener { confirmDeleteAllMemories() }
    }

    private fun setupLanguageSpinner() {
        val adapter = ArrayAdapter.createFromResource(
            this, R.array.language_options, android.R.layout.simple_spinner_item
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        binding.languageSpinner.adapter = adapter
    }

    private fun setupSpeechRateSeekBar() {
        binding.speechRateSeekBar.max = 30 // 0.5x .. 2.0x in 0.05 steps
        binding.speechRateSeekBar.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean
                ) {
                    binding.speechRateValue.text = getString(
                        R.string.speech_rate_value, rateFromProgress(progress)
                    )
                }

                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) = Unit
            }
        )
    }

    private fun rateFromProgress(progress: Int): Float = 0.5f + progress * 0.05f

    private fun progressFromRate(rate: Float): Int =
        ((rate - 0.5f) / 0.05f).toInt().coerceIn(0, 30)

    private fun loadAll() {
        // API keys are never displayed in full: the fields stay empty and only
        // the hint says whether a key is saved.
        binding.apiKeyEdit.hint = if (securePrefs.getApiKey().isNullOrBlank()) {
            getString(R.string.api_key_hint)
        } else {
            getString(R.string.key_saved_hint)
        }
        binding.ttsKeyEdit.hint = if (securePrefs.getTtsKey().isNullOrBlank()) {
            getString(R.string.tts_key_hint)
        } else {
            getString(R.string.key_saved_hint)
        }

        binding.userNameEdit.setText(securePrefs.getString(Constants.KEY_USER_NAME, ""))
        binding.primeNameEdit.setText(securePrefs.getString(Constants.KEY_PRIME_NAME, ""))
        binding.primeNumberEdit.setText(securePrefs.getString(Constants.KEY_PRIME_NUMBER, ""))
        binding.wakeWordEdit.setText(
            securePrefs.getString(Constants.KEY_WAKE_WORD, "myra")
        )

        when (
            securePrefs.getString(
                Constants.KEY_PERSONALITY, PersonalityMode.ASSISTANT.name
            )
        ) {
            PersonalityMode.GF_CARING.name -> binding.personalityRadioGroup.check(R.id.radioGf)
            PersonalityMode.PROFESSIONAL.name -> binding.personalityRadioGroup.check(R.id.radioProfessional)
            else -> binding.personalityRadioGroup.check(R.id.radioAssistant)
        }

        val language = securePrefs.getString(Constants.KEY_LANGUAGE, "auto")
        binding.languageSpinner.setSelection(
            languageValues.indexOf(language).takeIf { it >= 0 } ?: 0
        )

        when (securePrefs.getString(Constants.KEY_VOICE_TYPE, "system")) {
            "elevenlabs" -> binding.voiceEngineRadioGroup.check(R.id.radioElevenLabs)
            else -> binding.voiceEngineRadioGroup.check(R.id.radioSystemTts)
        }

        val rate = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .getFloat(Constants.KEY_SPEECH_RATE, 1.0f)
        binding.speechRateSeekBar.progress = progressFromRate(rate)
        binding.speechRateValue.text = getString(R.string.speech_rate_value, rate)

        binding.liveModeSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_LIVE_MODE, false)
        binding.callAnnounceSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_CALL_ANNOUNCE, false)
        binding.backgroundSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_BACKGROUND_MODE, false)
        binding.proactiveSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_PROACTIVE_ENABLED, true)
        binding.guestSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_GUEST_ALLOWED, true)
        binding.cameraRecognitionSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_CAMERA_RECOGNITION, false)
        binding.screenUnderstandingSwitch.isChecked =
            securePrefs.getBoolean(Constants.KEY_SCREEN_UNDERSTANDING, false)
        binding.memoryConsentSwitch.isChecked = securePrefs.hasMemoryConsent()

        quietStartMin = securePrefs.getInt(Constants.KEY_QUIET_START, 23 * 60)
        quietEndMin = securePrefs.getInt(Constants.KEY_QUIET_END, 7 * 60)
        binding.quietStartButton.text = formatMinutes(quietStartMin)
        binding.quietEndButton.text = formatMinutes(quietEndMin)
    }

    private fun saveAll() {
        val apiKey = binding.apiKeyEdit.text?.toString().orEmpty().trim()
        if (apiKey.isNotBlank()) {
            securePrefs.setApiKey(apiKey)
            binding.apiKeyEdit.text?.clear()
            binding.apiKeyEdit.hint = getString(R.string.key_saved_hint)
        }
        val ttsKey = binding.ttsKeyEdit.text?.toString().orEmpty().trim()
        if (ttsKey.isNotBlank()) {
            securePrefs.setTtsKey(ttsKey)
            binding.ttsKeyEdit.text?.clear()
            binding.ttsKeyEdit.hint = getString(R.string.key_saved_hint)
        }

        securePrefs.putString(
            Constants.KEY_USER_NAME,
            binding.userNameEdit.text?.toString().orEmpty().trim()
        )
        securePrefs.putString(
            Constants.KEY_PRIME_NAME,
            binding.primeNameEdit.text?.toString().orEmpty().trim()
        )
        securePrefs.putString(
            Constants.KEY_PRIME_NUMBER,
            binding.primeNumberEdit.text?.toString().orEmpty().trim()
        )
        securePrefs.putString(
            Constants.KEY_WAKE_WORD,
            binding.wakeWordEdit.text?.toString().orEmpty().trim().ifEmpty { "myra" }
        )

        val personality = when (binding.personalityRadioGroup.checkedRadioButtonId) {
            R.id.radioGf -> PersonalityMode.GF_CARING.name
            R.id.radioProfessional -> PersonalityMode.PROFESSIONAL.name
            else -> PersonalityMode.ASSISTANT.name
        }
        securePrefs.putString(Constants.KEY_PERSONALITY, personality)

        val language = languageValues[
            binding.languageSpinner.selectedItemPosition.coerceIn(languageValues.indices)
        ]
        securePrefs.putString(Constants.KEY_LANGUAGE, language)

        val voiceType = when (binding.voiceEngineRadioGroup.checkedRadioButtonId) {
            R.id.radioElevenLabs -> "elevenlabs"
            else -> "system"
        }
        securePrefs.putString(Constants.KEY_VOICE_TYPE, voiceType)

        val rate = rateFromProgress(binding.speechRateSeekBar.progress)
        getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putFloat(Constants.KEY_SPEECH_RATE, rate).apply()

        securePrefs.putBoolean(Constants.KEY_LIVE_MODE, binding.liveModeSwitch.isChecked)
        securePrefs.putBoolean(Constants.KEY_CALL_ANNOUNCE, binding.callAnnounceSwitch.isChecked)
        securePrefs.putBoolean(Constants.KEY_BACKGROUND_MODE, binding.backgroundSwitch.isChecked)
        securePrefs.putBoolean(Constants.KEY_PROACTIVE_ENABLED, binding.proactiveSwitch.isChecked)
        securePrefs.putBoolean(Constants.KEY_GUEST_ALLOWED, binding.guestSwitch.isChecked)
        securePrefs.putBoolean(
            Constants.KEY_CAMERA_RECOGNITION, binding.cameraRecognitionSwitch.isChecked
        )
        securePrefs.putBoolean(
            Constants.KEY_SCREEN_UNDERSTANDING, binding.screenUnderstandingSwitch.isChecked
        )
        securePrefs.setMemoryConsent(binding.memoryConsentSwitch.isChecked)
        securePrefs.putInt(Constants.KEY_QUIET_START, quietStartMin)
        securePrefs.putInt(Constants.KEY_QUIET_END, quietEndMin)

        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
    }

    private fun showTimePicker(currentMinutes: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(
            this,
            { _, hour, minute -> onPicked(hour * 60 + minute) },
            currentMinutes / 60, currentMinutes % 60, true
        ).show()
    }

    private fun formatMinutes(minutes: Int): String =
        "%02d:%02d".format(minutes / 60, minutes % 60)

    private fun requestDefaultAssistant() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = getSystemService(RoleManager::class.java)
                if (roleManager != null &&
                    roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)
                ) {
                    assistantRoleLauncher.launch(
                        roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)
                    )
                    return
                }
            }
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (e: Exception) {
            runCatching {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            }
        }
    }

    private fun confirmDeleteAllMemories() {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_memories_title)
            .setMessage(R.string.delete_memories_message)
            .setPositiveButton(R.string.delete) { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    runCatching { repository.deleteAllMemories() }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@SettingsActivity,
                            R.string.memories_deleted, Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
