package com.myra.assistant.screen

import android.content.Context
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.myra.assistant.models.ScreenElement
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Turns the accessibility element tree / OCR output into plain language MYRA
 * can speak, and finds elements by what the user says.
 */
class ScreenVision(private val context: Context) {

    /**
     * Plain-language summary of the elements currently on screen.
     * The app/package is not known here, so the summary lists what is
     * actually visible: clickable texts and descriptions, with a count.
     */
    fun describeCurrentScreen(elements: List<ScreenElement>): String {
        if (elements.isEmpty()) {
            return "The screen appears empty — I couldn't see any readable elements. / " +
                "স্ক্রিনটি খালি মনে হচ্ছে — কোনো পড়ার মতো কিছু দেখতে পাচ্ছি না।"
        }
        val clickable = elements.filter { it.isClickable }
        val named = elements.mapNotNull { el ->
            val label = el.text.ifBlank { el.contentDescription.orEmpty() }.trim()
            label.ifEmpty { null }
        }
        val shown = named.take(20)
        val summary = StringBuilder()
        summary.append("I can see ${elements.size} elements on screen")
        if (clickable.isNotEmpty()) summary.append(", ${clickable.size} of them clickable")
        summary.append(". ")
        if (shown.isNotEmpty()) {
            summary.append("Visible items: ${shown.joinToString(", ")}")
            if (named.size > shown.size) summary.append(", and ${named.size - shown.size} more")
            summary.append(".")
        } else {
            summary.append("None of them have readable text.")
        }
        return summary.toString()
    }

    /** Fuzzy match on an element's text or content description (case-insensitive). */
    fun findElement(elements: List<ScreenElement>, query: String): ScreenElement? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        return elements.firstOrNull { it.text.lowercase() == q }
            ?: elements.firstOrNull { it.contentDescription?.lowercase() == q }
            ?: elements.firstOrNull { it.text.lowercase().contains(q) }
            ?: elements.firstOrNull { it.contentDescription?.lowercase()?.contains(q) == true }
            ?: elements.firstOrNull { el ->
                q.split(Regex("\\s+")).filter { it.length > 2 }.any { word ->
                    el.text.lowercase().contains(word) ||
                        (el.contentDescription?.lowercase()?.contains(word) == true)
                }
            }
    }

    /** Recognise text in a bitmap with on-device ML Kit OCR. */
    suspend fun ocrFromBitmap(bitmap: Bitmap): Result<String> {
        return suspendCancellableCoroutine { cont ->
            try {
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val image = InputImage.fromBitmap(bitmap, 0)
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        if (cont.isActive) cont.resume(Result.success(visionText.text))
                    }
                    .addOnFailureListener { e ->
                        Logger.e("ScreenVision", "OCR failed", e)
                        if (cont.isActive) cont.resume(Result.failure(e))
                    }
            } catch (e: Exception) {
                Logger.e("ScreenVision", "OCR setup failed", e)
                if (cont.isActive) cont.resume(Result.failure(e))
            }
        }
    }

    /** Short spoken summary of OCR output: first 500 chars + line count. */
    fun summariseOcrText(text: String): String {
        if (text.isBlank()) return "No text found on screen. / স্ক্রিনে কোনো লেখা পাওয়া যায়নি।"
        val lines = text.lines().filter { it.isNotBlank() }
        val excerpt = text.take(500)
        val suffix = if (text.length > 500) "…" else ""
        return "I found ${lines.size} lines of text: $excerpt$suffix"
    }
}
