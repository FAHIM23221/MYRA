package com.myra.assistant

import android.app.Application
import com.myra.assistant.ai.ConversationManager
import com.myra.assistant.ai.GeminiClient
import com.myra.assistant.data.MemoryRepository
import com.myra.assistant.data.MyraDatabase
import com.myra.assistant.data.SecurePrefs

/**
 * Application entry point wiring the data / AI layer.
 *
 * Wired against the real data-layer API (data package):
 * - MyraDatabase.getInstance(context) — Room database "myra.db"
 * - MemoryRepository(context, dao, securePrefs)
 * - SecurePrefs(context)
 * - GeminiClient(apiKeyProvider = { securePrefs.getApiKey() })
 * - ConversationManager(repository, gemini) — EmotionEngine defaults
 */
class MyraApplication : Application() {

    private val database: MyraDatabase by lazy { MyraDatabase.getInstance(this) }

    val securePrefs: SecurePrefs by lazy { SecurePrefs(this) }

    val repository: MemoryRepository by lazy {
        MemoryRepository(this, database.myraDao(), securePrefs)
    }

    val gemini: GeminiClient by lazy {
        GeminiClient(apiKeyProvider = { securePrefs.getApiKey() })
    }

    val conversation: ConversationManager by lazy {
        ConversationManager(repository, gemini)
    }
}
