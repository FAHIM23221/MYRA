package com.myra.assistant.ai

import com.myra.assistant.models.CommandType
import com.myra.assistant.models.VoiceCommand

/**
 * Parses Bengali + English voice/text input into direct device commands.
 * Anything that does not match a known pattern is [CommandType.UNKNOWN]
 * and is left for the conversational AI to handle.
 */
object CommandProcessor {

    fun parse(text: String): VoiceCommand {
        val raw = text.trim()
        if (raw.isEmpty()) return VoiceCommand(raw, CommandType.UNKNOWN)
        val lower = raw.lowercase()

        // ---- Flashlight ----
        if (lower == "flashlight on" || lower == "turn on flashlight" ||
            lower.contains("টর্চ জ্বালাও") || lower.contains("ফ্ল্যাশলাইট জ্বালাও") ||
            lower.contains("টর্চ অন করো")
        ) return VoiceCommand(raw, CommandType.FLASHLIGHT_ON)
        if (lower == "flashlight off" || lower == "turn off flashlight" ||
            lower.contains("টর্চ বন্ধ করো") || lower.contains("টর্চ নেভাও") ||
            lower.contains("ফ্ল্যাশলাইট বন্ধ করো")
        ) return VoiceCommand(raw, CommandType.FLASHLIGHT_OFF)

        // ---- Volume ----
        if (lower.contains("volume up") || lower.contains("ভলিউম বাড়াও") ||
            lower.contains("আওয়াজ বাড়াও")
        ) return VoiceCommand(raw, CommandType.VOLUME_UP)
        if (lower.contains("volume down") || lower.contains("ভলিউম কমাও") ||
            lower.contains("আওয়াজ কমাও")
        ) return VoiceCommand(raw, CommandType.VOLUME_DOWN)

        // ---- Screen understanding ----
        if (lower.contains("look at my screen") || lower.contains("স্ক্রিন দেখো") ||
            lower.contains("স্ক্রিনটা দেখো")
        ) return VoiceCommand(raw, CommandType.LOOK_AT_SCREEN)
        if (lower.contains("explain screen") || lower.contains("explain my screen") ||
            lower.contains("স্ক্রিন বুঝিয়ে") || lower.contains("স্ক্রিনে কী আছে")
        ) return VoiceCommand(raw, CommandType.EXPLAIN_SCREEN)
        if (lower.contains("read screen") || lower.contains("read my screen") ||
            lower.contains("স্ক্রিন পড়ো") || lower.contains("স্ক্রিনটা পড়ে")
        ) return VoiceCommand(raw, CommandType.READ_SCREEN)
        findOnScreen(lower, raw)?.let { return it }

        // ---- WhatsApp call (before plain call) ----
        Regex("""^(?:whatsapp call|whatsapp কল)\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.WHATSAPP_CALL, arg = stripTrailingPunctuation(it.groupValues[1]))
        }
        Regex("""^(.+?)\s*(?:কে|কে\s+)?whatsapp\s*(?:কল|call)\s*(?:করো)?$""").find(lower)?.let {
            val name = it.groupValues[1].trim()
            if (name.isNotEmpty()) return VoiceCommand(raw, CommandType.WHATSAPP_CALL, arg = name)
        }

        // ---- Call ----
        Regex("""^call\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.CALL, arg = stripTrailingPunctuation(it.groupValues[1]))
        }
        Regex("""^(.+?)(?:কে)?\s+কল\s+করো$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.CALL, arg = it.groupValues[1].trim())
        }
        Regex("""^(.+?)(?:কে)?\s+ফোন\s+করো$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.CALL, arg = it.groupValues[1].trim())
        }

        // ---- SMS / message ----
        Regex("""^(?:sms|message|text)\s+(\S+)\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SMS, arg = it.groupValues[1], arg2 = it.groupValues[2])
        }
        Regex("""^(.+?)(?:কে)?\s+মেসেজ\s+পাঠাও\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SMS, arg = it.groupValues[1].trim(), arg2 = it.groupValues[2].trim())
        }
        Regex("""^(.+?)(?:কে)?\s+(?:মেসেজ|sms)\s+(?:করো\s+)?(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SMS, arg = it.groupValues[1].trim(), arg2 = it.groupValues[2].trim())
        }

        // ---- Music ----
        Regex("""^play\s+(.+?)\s+on\s+spotify$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SPOTIFY_PLAY, arg = it.groupValues[1])
        }
        Regex("""^play\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.PLAY_MUSIC, arg = it.groupValues[1])
        }
        Regex("""^(.+?)\s*(?:গান\s+)?চালাও$""").find(lower)?.let {
            val q = it.groupValues[1].trim()
            if (q.isNotEmpty()) return VoiceCommand(raw, CommandType.PLAY_MUSIC, arg = q)
        }
        if (lower == "গান চালাও" || lower == "play music" || lower == "play some music") {
            return VoiceCommand(raw, CommandType.PLAY_MUSIC)
        }

        // ---- Open app ----
        Regex("""^open\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.OPEN_APP, arg = stripTrailingPunctuation(it.groupValues[1]))
        }
        Regex("""^(.+?)\s+খোলো$""").find(lower)?.let {
            val app = it.groupValues[1].trim()
            if (app.isNotEmpty()) return VoiceCommand(raw, CommandType.OPEN_APP, arg = app)
        }

        // ---- Search ----
        Regex("""^search\s+(?:for\s+)?(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SEARCH, arg = it.groupValues[1])
        }
        Regex("""^(.+?)\s+খুঁজো$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SEARCH, arg = it.groupValues[1].trim())
        }
        Regex("""^(.+?)\s+খুঁজে\s+দাও$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.SEARCH, arg = it.groupValues[1].trim())
        }

        // ---- Alarm ----
        if (lower.startsWith("set alarm") || lower.contains("অ্যালার্ম দাও") ||
            lower.contains("অ্যালার্ম সেট করো")
        ) {
            return VoiceCommand(raw, CommandType.SET_ALARM, arg = raw)
        }

        // ---- Reminder ----
        if (lower.startsWith("set reminder") || lower.startsWith("remind me") ||
            lower.contains("মনে করিয়ে দাও") || lower.contains("রিমাইন্ডার দাও")
        ) {
            return VoiceCommand(raw, CommandType.SET_REMINDER, arg = raw)
        }

        // ---- Note ----
        Regex("""^(?:create note|take a note|note)\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.CREATE_NOTE, arg = it.groupValues[1])
        }
        Regex("""^নোট\s+(?:লেখো|লিখো)\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.CREATE_NOTE, arg = it.groupValues[1].trim())
        }

        return VoiceCommand(raw, CommandType.UNKNOWN)
    }

    private fun findOnScreen(lower: String, raw: String): VoiceCommand? {
        Regex("""^find\s+(.+?)\s+on\s+(?:my\s+)?screen$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.FIND_ON_SCREEN, arg = it.groupValues[1])
        }
        Regex("""^find\s+(.+)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.FIND_ON_SCREEN, arg = it.groupValues[1])
        }
        Regex("""^(.+?)\s+স্ক্রিনে\s+(?:খুঁজো|আছে\s+কি)$""").find(lower)?.let {
            return VoiceCommand(raw, CommandType.FIND_ON_SCREEN, arg = it.groupValues[1].trim())
        }
        return null
    }

    private fun stripTrailingPunctuation(value: String): String =
        value.trim().trimEnd('.', '!', '?', '।')

    fun isDirectCommand(text: String): Boolean =
        parse(text).type != CommandType.UNKNOWN
}
