package com.myra.assistant.security

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivityAppSelectionBinding
import com.myra.assistant.utils.Constants

/**
 * Pick which installed launchable apps are protected by the app lock.
 * Persisted as a StringSet under the "locked_packages" key in the plain
 * SharedPreferences file (Constants.PREFS_NAME). Toggles save immediately.
 */
class AppSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppSelectionBinding

    private val lockedPackages: MutableSet<String> by lazy {
        getSharedPreferences(Constants.PREFS_NAME, MODE_PRIVATE)
            .getStringSet(KEY_LOCKED_PACKAGES, emptySet())
            ?.toMutableSet() ?: mutableSetOf()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appRecycler.apply {
            layoutManager = LinearLayoutManager(this@AppSelectionActivity)
            adapter = AppAdapter(loadLaunchableApps())
        }
        binding.doneButton.setOnClickListener { finish() }
    }

    private fun loadLaunchableApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info ->
                val label = info.loadLabel(packageManager)?.toString() ?: return@mapNotNull null
                AppInfo(label, info.activityInfo.packageName)
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun persistLocked() {
        getSharedPreferences(Constants.PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_LOCKED_PACKAGES, lockedPackages.toSet())
            .apply()
    }

    private data class AppInfo(val label: String, val packageName: String)

    private inner class AppAdapter(
        private val apps: List<AppInfo>
    ) : RecyclerView.Adapter<AppAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val nameText: TextView = view.findViewById(R.id.appNameText)
            private val packageText: TextView = view.findViewById(R.id.appPackageText)
            private val checkBox: CheckBox = view.findViewById(R.id.appCheckBox)

            fun bind(app: AppInfo) {
                nameText.text = app.label
                packageText.text = app.packageName
                checkBox.setOnCheckedChangeListener(null)
                checkBox.isChecked = app.packageName in lockedPackages
                checkBox.setOnCheckedChangeListener { _, checked ->
                    if (checked) lockedPackages.add(app.packageName)
                    else lockedPackages.remove(app.packageName)
                    persistLocked()
                }
                itemView.setOnClickListener { checkBox.toggle() }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_app_lock, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(apps[position])
        override fun getItemCount(): Int = apps.size
    }

    companion object {
        const val KEY_LOCKED_PACKAGES = "locked_packages"
    }
}
