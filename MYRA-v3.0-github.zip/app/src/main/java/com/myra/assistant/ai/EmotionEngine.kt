package com.myra.assistant.ai

import com.myra.assistant.models.Mood
import com.myra.assistant.models.PersonalityMode

/**
 * Keyword-based mood detection (Bengali + English) and tone adaptation.
 *
 * IMPORTANT — MYRA's emotional boundaries:
 * MYRA never claims human feelings, never pretends to feel sad/happy/lonely
 * itself, never manipulates the user, and never creates emotional dependency.
 * It recognises the *user's* mood from their words and responds with
 * appropriate care — as a tool that listens, not as a person that feels.
 * Mood detection is a heuristic, never a diagnosis.
 */
object EmotionEngine {

    private val keywords: List<Pair<Mood, List<String>>> = listOf(
        Mood.JOKING to listOf("হাহা", "হা হা", "lol", "😂", "🤣", "মজা", "হাসি", "funny", "joke", "হাস্যকর"),
        Mood.ANGRY to listOf("রাগ", "রেগে", "angry", "furious", "বিরক্ত", "mad at", "অসহ্য", "rage", "খুব রাগ"),
        Mood.STRESSED to listOf("টেনশন", "stress", "stressed", "চাপ", "worried", "দুশ্চিন্তা", "অস্থির", "anxious", "panic"),
        Mood.LONELY to listOf("একা", "lonely", "কেউ নেই", "alone", "নিঃসঙ্গ", "nobody cares", "কেউ বোঝে না"),
        Mood.TIRED to listOf("ক্লান্ত", "tired", "ঘুম", "sleepy", "exhausted", "ঘুম পাচ্ছে", "শরীর খারাপ লাগছে"),
        Mood.SAD to listOf("দুঃখ", "কষ্ট", "sad", "crying", "মন খারাপ", "কাঁদতে", "depressed", "খারাপ লাগছে", "ভেঙে গেছে"),
        Mood.EXCITED to listOf("excited", "দারুণ", "wow!", "amazing", "অসাধারণ", "can't wait", "দারুন", "awesome!"),
        Mood.HAPPY to listOf("খুশি", "happy", "great", "ভালো লাগছে", "awesome", "ভালো আছি", "wonderful", "খুব ভালো", "দারুণ লাগছে"),
        Mood.BUSY to listOf("ব্যস্ত", "busy", "পরে", "later", "no time", "সময় নেই", "in a hurry", "তাড়া আছে")
    )

    /**
     * Scores [text] plus [recentTurns] (earlier turns count less) against the
     * keyword lists. Returns the best-scoring mood, or NEUTRAL when nothing
     * matches. On a tie, the earlier entry in [keywords] wins.
     */
    fun detectMood(text: String, recentTurns: List<String> = emptyList()): Mood {
        val haystack = text.lowercase()
        val context = recentTurns.joinToString(" ").lowercase()
        var bestMood = Mood.NEUTRAL
        var bestScore = 0
        for ((mood, words) in keywords) {
            var score = 0
            for (word in words) {
                if (haystack.contains(word)) score += 2
                if (context.contains(word)) score += 1
            }
            if (score > bestScore) {
                bestScore = score
                bestMood = mood
            }
        }
        return bestMood
    }

    /**
     * Adjusts [base] for the user's [mood] and MYRA's [personality].
     * Sad/angry/stressed replies stay patient and calm — no generic
     * motivational spam, no jokes when the user is angry.
     */
    fun adaptReply(base: String, mood: Mood, personality: PersonalityMode): String {
        if (base.isBlank()) return base
        var reply = when (mood) {
            Mood.SAD -> "শুনছি, আস্তে করে বলো। আমি এখানেই আছি। $base"
            Mood.ANGRY -> "ঠিক আছে, শান্তভাবে দেখি। $base"
            Mood.STRESSED -> "একটু শ্বাস নাও, আমরা একসাথে সামলে নেব। $base"
            Mood.LONELY -> "তুমি একা নও, আমি আছি। $base"
            Mood.TIRED -> shorten(base, 1) + " একটু বিশ্রাম নিও।"
            Mood.BUSY -> shorten(base, 2)
            Mood.HAPPY -> "দারুণ! $base"
            Mood.EXCITED -> "বাহ, দারুণ! $base"
            Mood.JOKING -> "$base 😄"
            Mood.NEUTRAL -> base
        }
        if (personality == PersonalityMode.PROFESSIONAL) {
            // Professional mode: keep it crisp, drop playful emoji.
            reply = reply.replace(" 😄", "").replace("😄", "").trim()
        }
        return reply.trim()
    }

    /** Keeps only the first [maxSentences] sentences of [text]. */
    private fun shorten(text: String, maxSentences: Int): String {
        val sentences = text.split(Regex("(?<=[.!?।])\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        if (sentences.size <= maxSentences) return text.trim()
        return sentences.take(maxSentences).joinToString(" ")
    }

    /**
     * A respectful disagreement: states a different view honestly, without
     * pressure, flattery, or pretending to be human. Never manipulative.
     */
    fun respectfulDisagreement(topic: String): String {
        return "এই বিষয়ে ($topic) আমার ভাবনাটা একটু আলাদা — তবে আমি ভুলও হতে পারি, " +
            "আর তোমার মতামতকে আমি সম্মান করি। তুমি যেভাবে দেখছো, সেটাও বোঝার চেষ্টা করছি।"
    }
}
