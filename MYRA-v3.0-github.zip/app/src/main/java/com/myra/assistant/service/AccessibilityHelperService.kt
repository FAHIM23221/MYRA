package com.myra.assistant.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.assistant.models.ScreenElement
import com.myra.assistant.utils.Logger

/**
 * Reads the on-screen element tree (text, descriptions, clickable state,
 * bounds) so MYRA can describe, find and tap things the user asks about.
 *
 * NOTE: this file lives in the `service` package (not `accessibility`)
 * because AndroidManifest.xml already declares it as
 * `.service.AccessibilityHelperService`.
 */
class AccessibilityHelperService : AccessibilityService() {

    companion object {
        private const val TAG = "AccessibilityService"
        private const val MAX_ELEMENTS = 200

        @Volatile
        var instance: AccessibilityHelperService? = null
            private set

        @Volatile
        var lastElements: List<ScreenElement> = emptyList()
            private set

        fun getCurrentElements(): List<ScreenElement> = lastElements
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Logger.i(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                val root = rootInActiveWindow ?: return
                try {
                    val collected = mutableListOf<ScreenElement>()
                    traverse(root, collected)
                    lastElements = collected
                } catch (e: Exception) {
                    Logger.e(TAG, "Failed to collect screen elements", e)
                }
            }
            else -> Unit
        }
    }

    override fun onInterrupt() {
        Logger.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Null-safe depth-first traversal, capped at [MAX_ELEMENTS]. */
    private fun traverse(node: AccessibilityNodeInfo?, out: MutableList<ScreenElement>) {
        if (node == null || out.size >= MAX_ELEMENTS) return
        try {
            val text = node.text?.toString().orEmpty()
            val description = node.contentDescription?.toString()
            val className = node.className?.toString()
            val clickable = node.isClickable
            if (text.isNotBlank() || !description.isNullOrBlank() || clickable) {
                val bounds = Rect()
                try {
                    node.getBoundsInScreen(bounds)
                } catch (e: Exception) {
                    // Bounds are best-effort; keep the element without them.
                    bounds.setEmpty()
                }
                out.add(
                    ScreenElement(
                        text = text,
                        contentDescription = description,
                        className = className,
                        isClickable = clickable,
                        bounds = if (bounds.isEmpty) null else Rect(bounds)
                    )
                )
            }
            for (i in 0 until node.childCount) {
                if (out.size >= MAX_ELEMENTS) break
                traverse(node.getChild(i), out)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Traversal failed on a node", e)
        }
    }

    /** Tap the node matching [element] by text; falls back to its description. */
    fun performClickOn(element: ScreenElement): Boolean {
        val root = rootInActiveWindow ?: return false
        val query = element.text.ifBlank { element.contentDescription.orEmpty() }
        if (query.isBlank()) return false
        return try {
            val nodes = root.findAccessibilityNodeInfosByText(query)
            val target = nodes.firstOrNull { it.isClickable }
                ?: nodes.firstOrNull()
                ?: return false
            var node: AccessibilityNodeInfo? = target
            var clicked = false
            // Walk up to the nearest clickable ancestor.
            while (node != null && !clicked) {
                if (node.isClickable) {
                    clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                node = node.parent
            }
            clicked
        } catch (e: Exception) {
            Logger.e(TAG, "performClickOn failed", e)
            false
        }
    }

    fun performScrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        return try {
            root.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        } catch (e: Exception) {
            Logger.e(TAG, "performScrollForward failed", e)
            false
        }
    }

    /** Type [text] into the currently focused editable field. */
    fun typeText(text: String) {
        val root = rootInActiveWindow ?: return
        try {
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
            if (!focused.isEditable) return
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    text
                )
            }
            focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } catch (e: Exception) {
            Logger.e(TAG, "typeText failed", e)
        }
    }
}
