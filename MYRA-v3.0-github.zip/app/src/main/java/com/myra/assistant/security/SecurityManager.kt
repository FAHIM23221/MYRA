package com.myra.assistant.security

import android.content.Context
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.myra.assistant.data.SecurePrefs
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID

/**
 * PIN / pattern / voice-passphrase / biometric gate for MYRA owner-only areas.
 *
 * Storage: SecurePrefs (EncryptedSharedPreferences-backed). PINs, patterns and
 * voice passphrases are stored ONLY as salted SHA-256 hashes — never plaintext.
 * 5 wrong PIN/pattern attempts = 5-minute lockout.
 */
class SecurityManager(context: Context) {

    private val prefs = SecurePrefs(context)

    enum class PinResult { CORRECT, WRONG, NOT_SET, LOCKED_OUT }

    companion object {
        const val KEY_PIN_HASH = "lock_pin_hash"
        const val KEY_PIN_SALT = "lock_pin_salt"
        const val KEY_PIN_ATTEMPTS = "lock_pin_attempts"
        const val KEY_PIN_LOCKOUT_UNTIL = "lock_pin_lockout_until"
        const val KEY_PATTERN_HASH = "lock_pattern_hash"
        const val KEY_PATTERN_SALT = "lock_pattern_salt"
        const val KEY_PATTERN_ATTEMPTS = "lock_pattern_attempts"
        const val KEY_PATTERN_LOCKOUT_UNTIL = "lock_pattern_lockout_until"
        const val KEY_VOICE_HASH = "lock_voice_hash"
        const val KEY_VOICE_SALT = "lock_voice_salt"
        const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"

        const val MAX_ATTEMPTS = 5
        const val LOCKOUT_MILLIS = 5L * 60L * 1000L
    }

    // ---- hashing ----

    private fun newSalt(): String = UUID.randomUUID().toString()

    private fun hashWithSalt(value: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("$salt:$value".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // ---- PIN ----

    /** Stores only a salted hash. PIN must be at least 4 characters. */
    fun setPin(pin: String) {
        require(pin.length >= 4) { "PIN must be at least 4 characters" }
        val salt = newSalt()
        prefs.putString(KEY_PIN_SALT, salt)
        prefs.putString(KEY_PIN_HASH, hashWithSalt(pin, salt))
        prefs.putInt(KEY_PIN_ATTEMPTS, 0)
        prefs.putString(KEY_PIN_LOCKOUT_UNTIL, "0")
    }

    fun hasPin(): Boolean = prefs.getString(KEY_PIN_HASH, "").isNotEmpty()

    fun removePin() {
        prefs.putString(KEY_PIN_HASH, "")
        prefs.putString(KEY_PIN_SALT, "")
        prefs.putInt(KEY_PIN_ATTEMPTS, 0)
        prefs.putString(KEY_PIN_LOCKOUT_UNTIL, "0")
    }

    fun verifyPin(pin: String): PinResult {
        if (lockoutRemainingMillis(KEY_PIN_LOCKOUT_UNTIL) > 0) return PinResult.LOCKED_OUT
        val storedHash = prefs.getString(KEY_PIN_HASH, "")
        if (storedHash.isEmpty()) return PinResult.NOT_SET
        val salt = prefs.getString(KEY_PIN_SALT, "")
        return if (hashWithSalt(pin, salt) == storedHash) {
            prefs.putInt(KEY_PIN_ATTEMPTS, 0)
            PinResult.CORRECT
        } else {
            recordFailedAttempt(KEY_PIN_ATTEMPTS, KEY_PIN_LOCKOUT_UNTIL)
            PinResult.WRONG
        }
    }

    fun remainingPinAttempts(): Int =
        (MAX_ATTEMPTS - prefs.getInt(KEY_PIN_ATTEMPTS, 0)).coerceAtLeast(0)

    fun pinLockoutRemainingMillis(): Long = lockoutRemainingMillis(KEY_PIN_LOCKOUT_UNTIL)

    // ---- Pattern ----
    // Pattern is stored as the joined node order, e.g. "0,1,4,8" — hashed like a PIN.

    fun setPattern(pattern: String) {
        require(pattern.isNotBlank()) { "Pattern must not be empty" }
        val salt = newSalt()
        prefs.putString(KEY_PATTERN_SALT, salt)
        prefs.putString(KEY_PATTERN_HASH, hashWithSalt(pattern, salt))
        prefs.putInt(KEY_PATTERN_ATTEMPTS, 0)
        prefs.putString(KEY_PATTERN_LOCKOUT_UNTIL, "0")
    }

    fun hasPattern(): Boolean = prefs.getString(KEY_PATTERN_HASH, "").isNotEmpty()

    fun removePattern() {
        prefs.putString(KEY_PATTERN_HASH, "")
        prefs.putString(KEY_PATTERN_SALT, "")
        prefs.putInt(KEY_PATTERN_ATTEMPTS, 0)
        prefs.putString(KEY_PATTERN_LOCKOUT_UNTIL, "0")
    }

    fun verifyPattern(pattern: String): PinResult {
        if (lockoutRemainingMillis(KEY_PATTERN_LOCKOUT_UNTIL) > 0) return PinResult.LOCKED_OUT
        val storedHash = prefs.getString(KEY_PATTERN_HASH, "")
        if (storedHash.isEmpty()) return PinResult.NOT_SET
        val salt = prefs.getString(KEY_PATTERN_SALT, "")
        return if (hashWithSalt(pattern, salt) == storedHash) {
            prefs.putInt(KEY_PATTERN_ATTEMPTS, 0)
            PinResult.CORRECT
        } else {
            recordFailedAttempt(KEY_PATTERN_ATTEMPTS, KEY_PATTERN_LOCKOUT_UNTIL)
            PinResult.WRONG
        }
    }

    fun remainingPatternAttempts(): Int =
        (MAX_ATTEMPTS - prefs.getInt(KEY_PATTERN_ATTEMPTS, 0)).coerceAtLeast(0)

    // ---- Voice passphrase ----
    // Compared on a normalised form (lowercase, trimmed, collapsed whitespace)
    // against the stored salted hash. The spoken phrase itself is never stored.

    fun setVoicePassphrase(phrase: String) {
        val normalised = normalisePhrase(phrase)
        require(normalised.length >= 3) { "Voice passphrase must be at least 3 characters" }
        val salt = newSalt()
        prefs.putString(KEY_VOICE_SALT, salt)
        prefs.putString(KEY_VOICE_HASH, hashWithSalt(normalised, salt))
    }

    fun hasVoicePassphrase(): Boolean = prefs.getString(KEY_VOICE_HASH, "").isNotEmpty()

    fun removeVoicePassphrase() {
        prefs.putString(KEY_VOICE_HASH, "")
        prefs.putString(KEY_VOICE_SALT, "")
    }

    fun verifyVoicePassphrase(phrase: String): Boolean {
        val storedHash = prefs.getString(KEY_VOICE_HASH, "")
        if (storedHash.isEmpty()) return false
        val salt = prefs.getString(KEY_VOICE_SALT, "")
        return hashWithSalt(normalisePhrase(phrase), salt) == storedHash
    }

    private fun normalisePhrase(phrase: String): String =
        phrase.trim().lowercase(Locale.ROOT).replace("\\s+".toRegex(), " ")

    // ---- Biometric ----

    fun isBiometricEnabled(): Boolean = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.putBoolean(KEY_BIOMETRIC_ENABLED, enabled)
    }

    fun authenticateWithBiometric(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onError(errString.toString())
                }

                override fun onAuthenticationFailed() {
                    onError("Authentication failed — try again")
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Verify it's you — MYRA owner")
            .setSubtitle("Use your fingerprint to unlock MYRA")
            .setAllowedAuthenticators(
                androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
            )
            .build()
        prompt.authenticate(info)
    }

    // ---- helpers ----

    private fun recordFailedAttempt(attemptsKey: String, lockoutKey: String) {
        val attempts = prefs.getInt(attemptsKey, 0) + 1
        if (attempts >= MAX_ATTEMPTS) {
            prefs.putInt(attemptsKey, 0)
            prefs.putString(lockoutKey, (System.currentTimeMillis() + LOCKOUT_MILLIS).toString())
        } else {
            prefs.putInt(attemptsKey, attempts)
        }
    }

    private fun lockoutRemainingMillis(lockoutKey: String): Long {
        val until = prefs.getString(lockoutKey, "0").toLongOrNull() ?: 0L
        return (until - System.currentTimeMillis()).coerceAtLeast(0L)
    }
}
