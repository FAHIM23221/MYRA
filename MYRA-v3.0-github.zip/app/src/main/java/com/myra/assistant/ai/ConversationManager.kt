package com.myra.assistant.ai

import com.myra.assistant.data.MemoryRepository
import com.myra.assistant.models.ContactProfile
import com.myra.assistant.models.Mood
import com.myra.assistant.models.PersonalityMode
import com.myra.assistant.models.SessionRole
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger

/**
 * Orchestrates one conversation turn: mood detection, consented memory
 * context, Gemini call, tone adaptation, and (owner-only) turn storage.
 *
 * Privacy rule: guests and contacts NEVER receive private memory context,
 * and their turns are NEVER saved. Only the owner, with memory consent,
 * gets memory loaded and turns stored.
 */
class ConversationManager(
    private val repository: MemoryRepository,
    private val gemini: GeminiClient,
    private val emotion: EmotionEngine = EmotionEngine
) {
    var currentRole: SessionRole = SessionRole.OWNER
        private set

    var currentContactName: String? = null
        private set

    var isGuest: Boolean = false
        private set

    suspend fun respond(userText: String, prefs: Map<String, String>): Result<String> {
        if (userText.isBlank()) {
            return Result.failure(IllegalArgumentException("Empty message."))
        }
        val userName = prefs[Constants.KEY_USER_NAME]?.takeIf { it.isNotBlank() } ?: "friend"
        val personality = runCatching {
            PersonalityMode.valueOf(
                prefs[Constants.KEY_PERSONALITY]?.takeIf { it.isNotBlank() } ?: "ASSISTANT"
            )
        }.getOrDefault(PersonalityMode.ASSISTANT)

        val isOwner = currentRole == SessionRole.OWNER

        // Recent turns only feed mood detection for the owner.
        val recentTurnTexts: List<String> = if (isOwner) {
            runCatching { repository.getRecentTurns(5).map { it.text } }.getOrDefault(emptyList())
        } else {
            emptyList()
        }
        val mood: Mood = emotion.detectMood(userText, recentTurnTexts)

        // Private memory context only for the owner.
        val memoryContext: String = if (isOwner) {
            runCatching { repository.buildMemoryContext() }.getOrDefault("")
        } else {
            ""
        }

        val systemPrompt = gemini.buildSystemPrompt(userName, personality, mood, memoryContext)
        val result = gemini.generateText(userText, systemPrompt)
        if (result.isFailure) {
            Logger.w("ConversationManager", "Gemini call failed")
            return result
        }
        val adapted = emotion.adaptReply(result.getOrThrow(), mood, personality)

        // Save turns only for the owner, and only with memory consent
        // (MemoryRepository.saveTurn enforces both checks itself).
        if (isOwner) {
            runCatching {
                repository.saveTurn(userText, isUser = true, role = SessionRole.OWNER, mood = mood)
                repository.saveTurn(adapted, isUser = false, role = SessionRole.OWNER, mood = mood)
            }.onFailure { e ->
                Logger.e("ConversationManager", "Could not save turn", e)
            }
        }
        return Result.success(adapted)
    }

    /** Starts a guest session: no private memory, no turn storage, fresh context. */
    fun startGuestSession() {
        currentRole = SessionRole.GUEST
        currentContactName = null
        isGuest = true
        Logger.i("ConversationManager", "Guest session started")
    }

    /** Ends a guest session and returns to the owner. */
    fun endGuestSession() {
        switchToOwner()
        Logger.i("ConversationManager", "Guest session ended")
    }

    /**
     * Starts a session for an enrolled contact. Greets them by their
     * preferred address. No private owner memory is ever exposed.
     */
    fun startContactSession(profile: ContactProfile): String {
        currentRole = SessionRole.CONTACT
        currentContactName = profile.name
        isGuest = false
        val address = profile.preferredAddress.takeIf { it.isNotBlank() } ?: profile.name
        return "হ্যালো $address! আমি MYRA। কিভাবে সাহায্য করতে পারি?"
    }

    /** Returns to the owner session. */
    fun switchToOwner() {
        currentRole = SessionRole.OWNER
        currentContactName = null
        isGuest = false
    }
}
