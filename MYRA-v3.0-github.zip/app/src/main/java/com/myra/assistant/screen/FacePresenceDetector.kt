package com.myra.assistant.screen

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * PRESENCE ONLY — this detects whether a face is present in a frame.
 *
 * It does NOT identify anyone, produces no embedding / template / feature
 * vector, stores nothing, and compares the face against nobody. The result
 * is a single boolean: "a face is present" or "no face is present".
 *
 * Used only to know whether someone is in front of the camera during an
 * opted-in presence session (see KEY_CAMERA_RECOGNITION, default off).
 * No other face code exists in this app.
 */
object FacePresenceDetector {

    private val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .build()

    /** Returns true if at least one face is detected in [bitmap]. */
    suspend fun hasFace(bitmap: Bitmap): Result<Boolean> {
        return suspendCancellableCoroutine { cont ->
            try {
                val detector = FaceDetection.getClient(options)
                val image = InputImage.fromBitmap(bitmap, 0)
                detector.process(image)
                    .addOnSuccessListener { faces ->
                        // Boolean only — no face data leaves this callback.
                        if (cont.isActive) cont.resume(Result.success(faces.isNotEmpty()))
                    }
                    .addOnFailureListener { e ->
                        Logger.e("FacePresenceDetector", "Face detection failed", e)
                        if (cont.isActive) cont.resume(Result.failure(e))
                    }
            } catch (e: Exception) {
                Logger.e("FacePresenceDetector", "Face detection setup failed", e)
                if (cont.isActive) cont.resume(Result.failure(e))
            }
        }
    }
}
