package com.myra.assistant.ui.memory

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.MyraApplication
import com.myra.assistant.R
import com.myra.assistant.data.MemoryEntity
import com.myra.assistant.databinding.ActivityMemoryBinding
import com.myra.assistant.models.ContactProfile
import com.myra.assistant.screen.FacePresenceDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Memories (Flow<List<MemoryEntity>>) with per-row Edit / Delete, JSON
 * export / import, delete-all, plus the enrolled-contacts list.
 *
 * Adding a contact is owner-typed only: name / relationship / address /
 * notes / phone are typed by the user, never taken from a photo. The
 * optional gallery photo is checked ONLY for face presence
 * (FacePresenceDetector.hasFace → boolean flag), never for identity.
 */
class MemoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMemoryBinding
    private val repository by lazy { (application as MyraApplication).repository }

    private val memoryAdapter = MemoryAdapter()
    private val contactAdapter = ContactAdapter()

    // State for the add-contact dialog while a photo face-check is running.
    private var addContactFaceStatus: TextView? = null
    private var addContactFacePresent: Boolean = false

    private val importPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch(Dispatchers.IO) {
            val json = contentResolver.openInputStream(uri)
                ?.bufferedReader()?.readText().orEmpty()
            val count = runCatching { repository.importMemories(json) }.getOrDefault(0)
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@MemoryActivity,
                    getString(R.string.import_result, count), Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private val photoPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        checkFacePresence(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMemoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.memoryRecycler.apply {
            layoutManager = LinearLayoutManager(this@MemoryActivity)
            adapter = memoryAdapter
        }
        binding.contactsRecycler.apply {
            layoutManager = LinearLayoutManager(this@MemoryActivity)
            adapter = contactAdapter
        }

        lifecycleScope.launch {
            repository.getAllMemories().collect { memories ->
                memoryAdapter.submit(memories)
                binding.emptyMemoriesText.visibility =
                    if (memories.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        lifecycleScope.launch {
            repository.getContacts().collect { contacts ->
                contactAdapter.submit(contacts)
            }
        }

        binding.exportButton.setOnClickListener { exportMemories() }
        binding.importButton.setOnClickListener { importPicker.launch("*/*") }
        binding.deleteAllButton.setOnClickListener { confirmDeleteAll() }
        binding.addContactButton.setOnClickListener { showAddContactDialog() }
    }

    private fun exportMemories() {
        lifecycleScope.launch(Dispatchers.IO) {
            val json = runCatching { repository.exportMemories() }.getOrDefault("[]")
            withContext(Dispatchers.Main) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_TEXT, json)
                    putExtra(Intent.EXTRA_SUBJECT, "MYRA memories")
                }
                startActivity(Intent.createChooser(send, getString(R.string.export)))
            }
        }
    }

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_memories_title)
            .setMessage(R.string.delete_memories_message)
            .setPositiveButton(R.string.delete) { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    runCatching { repository.deleteAllMemories() }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MemoryActivity, R.string.memories_deleted, Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showEditMemoryDialog(entry: MemoryEntity) {
        val input = EditText(this).apply {
            setText(entry.value)
            hint = getString(R.string.memory_value)
        }
        AlertDialog.Builder(this)
            .setTitle(entry.key)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val newValue = input.text?.toString().orEmpty()
                if (newValue.isBlank()) return@setPositiveButton
                lifecycleScope.launch(Dispatchers.IO) {
                    val saved = runCatching {
                        repository.saveMemory(entry.key, newValue, entry.category)
                    }.getOrDefault(false)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MemoryActivity,
                            if (saved) R.string.memory_saved else R.string.memory_save_failed,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showAddContactDialog() {
        addContactFacePresent = false
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_contact, null)
        val nameEdit: EditText = view.findViewById(R.id.contactNameEdit)
        val relationshipEdit: EditText = view.findViewById(R.id.contactRelationshipEdit)
        val addressEdit: EditText = view.findViewById(R.id.contactAddressEdit)
        val notesEdit: EditText = view.findViewById(R.id.contactNotesEdit)
        val phoneEdit: EditText = view.findViewById(R.id.contactPhoneEdit)
        val consentCheck: CheckBox = view.findViewById(R.id.contactConsentCheck)
        val faceStatus: TextView = view.findViewById(R.id.contactFaceStatus)
        val pickPhotoButton: Button = view.findViewById(R.id.contactPickPhotoButton)
        addContactFaceStatus = faceStatus
        faceStatus.text = getString(R.string.face_not_checked)
        pickPhotoButton.setOnClickListener { photoPicker.launch("image/*") }

        AlertDialog.Builder(this)
            .setTitle(R.string.add_contact)
            .setView(view)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = nameEdit.text?.toString().orEmpty().trim()
                if (name.isBlank()) {
                    Toast.makeText(this, R.string.contact_name_required, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (!consentCheck.isChecked) {
                    Toast.makeText(this, R.string.contact_consent_required, Toast.LENGTH_SHORT)
                        .show()
                    return@setPositiveButton
                }
                val profile = ContactProfile(
                    name = name,
                    relationship = relationshipEdit.text?.toString().orEmpty().trim(),
                    preferredAddress = addressEdit.text?.toString().orEmpty().trim(),
                    notes = notesEdit.text?.toString().orEmpty().trim(),
                    phoneNumber = phoneEdit.text?.toString().orEmpty().trim().ifEmpty { null },
                    enrolledByOwner = true,
                    facePresentInPhoto = addContactFacePresent
                )
                lifecycleScope.launch(Dispatchers.IO) {
                    runCatching { repository.saveContact(profile) }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@MemoryActivity, R.string.contact_saved, Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .setOnDismissListener { addContactFaceStatus = null }
            .show()
    }

    private fun checkFacePresence(uri: Uri) {
        addContactFaceStatus?.text = getString(R.string.face_checking)
        lifecycleScope.launch(Dispatchers.IO) {
            val bitmap = decodeSampledBitmap(uri)
            val present = if (bitmap == null) {
                null
            } else {
                FacePresenceDetector.hasFace(bitmap).getOrNull()
            }
            withContext(Dispatchers.Main) {
                when (present) {
                    true -> {
                        addContactFacePresent = true
                        addContactFaceStatus?.text = getString(R.string.face_present)
                    }
                    false -> {
                        addContactFacePresent = false
                        addContactFaceStatus?.text = getString(R.string.face_absent)
                    }
                    null -> {
                        addContactFacePresent = false
                        addContactFaceStatus?.text = getString(R.string.face_check_failed)
                    }
                }
            }
        }
    }

    private fun decodeSampledBitmap(uri: Uri, maxDim: Int = 1024): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            val maxSide = maxOf(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (maxSide / sample > maxDim) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------ adapters

    private inner class MemoryAdapter : RecyclerView.Adapter<MemoryAdapter.VH>() {
        private var items: List<MemoryEntity> = emptyList()

        fun submit(list: List<MemoryEntity>) {
            items = list
            notifyDataSetChanged()
        }

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val keyText: TextView = view.findViewById(R.id.memoryKeyText)
            private val valueText: TextView = view.findViewById(R.id.memoryValueText)
            private val categoryText: TextView = view.findViewById(R.id.memoryCategoryText)
            private val editButton: Button = view.findViewById(R.id.memoryEditButton)
            private val deleteButton: Button = view.findViewById(R.id.memoryDeleteButton)

            fun bind(entry: MemoryEntity) {
                keyText.text = entry.key
                valueText.text = entry.value
                categoryText.text = entry.category
                editButton.setOnClickListener { showEditMemoryDialog(entry) }
                deleteButton.setOnClickListener {
                    lifecycleScope.launch(Dispatchers.IO) {
                        runCatching { repository.deleteMemory(entry.id) }
                    }
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_memory, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
        override fun getItemCount(): Int = items.size
    }

    private inner class ContactAdapter : RecyclerView.Adapter<ContactAdapter.VH>() {
        private var items: List<ContactProfile> = emptyList()

        fun submit(list: List<ContactProfile>) {
            items = list
            notifyDataSetChanged()
        }

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val nameText: TextView = view.findViewById(R.id.contactNameText)
            private val detailText: TextView = view.findViewById(R.id.contactDetailText)
            private val deleteButton: Button = view.findViewById(R.id.contactDeleteButton)

            fun bind(contact: ContactProfile) {
                nameText.text = contact.name
                detailText.text = listOf(
                    contact.relationship,
                    contact.preferredAddress,
                    contact.phoneNumber.orEmpty()
                ).filter { it.isNotBlank() }.joinToString(" · ")
                itemView.setOnClickListener {
                    startActivity(
                        Intent(this@MemoryActivity, ContactProfileActivity::class.java).apply {
                            putExtra(ContactProfileActivity.EXTRA_CONTACT_ID, contact.id)
                            putExtra(ContactProfileActivity.EXTRA_NAME, contact.name)
                            putExtra(ContactProfileActivity.EXTRA_RELATIONSHIP, contact.relationship)
                            putExtra(ContactProfileActivity.EXTRA_ADDRESS, contact.preferredAddress)
                            putExtra(ContactProfileActivity.EXTRA_NOTES, contact.notes)
                            putExtra(ContactProfileActivity.EXTRA_PHONE, contact.phoneNumber)
                            putExtra(
                                ContactProfileActivity.EXTRA_FACE_PRESENT,
                                contact.facePresentInPhoto
                            )
                        }
                    )
                }
                deleteButton.setOnClickListener {
                    lifecycleScope.launch(Dispatchers.IO) {
                        runCatching { repository.deleteContact(contact.id) }
                    }
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_contact, parent, false)
            return VH(view)
        }

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
        override fun getItemCount(): Int = items.size
    }
}
