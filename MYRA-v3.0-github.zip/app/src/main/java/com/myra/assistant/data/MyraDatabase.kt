package com.myra.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(
    entities = [
        MemoryEntity::class,
        ContactEntity::class,
        ReminderEntity::class,
        RoutineEntity::class,
        TurnEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MyraDatabase : RoomDatabase() {

    abstract fun myraDao(): MyraDao

    companion object {
        private const val DB_NAME = "myra.db"

        @Volatile
        private var instance: MyraDatabase? = null

        fun getInstance(context: Context): MyraDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MyraDatabase::class.java,
                    DB_NAME
                )
                    // No destructive migration: version 1 is the first release schema.
                    // Future versions must add an explicit Migration.
                    .build()
                    .also { instance = it }
            }
        }
    }
}
