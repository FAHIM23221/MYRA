package com.myra.assistant.security

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivityAppLockBinding
import java.util.Locale

/**
 * Owner lock screen with 4 tabs: PIN / Pattern / Voice / Finger.
 *
 * - PIN: on-screen pad, verified against the salted hash in SecurityManager.
 * - Pattern: 3x3 grid recording tap order, verified the same way.
 * - Voice: one-shot SpeechRecognizer listen, compared to the stored
 *   voice passphrase (normalised, hashed — never stored or logged).
 * - Finger: BiometricPrompt (BIOMETRIC_STRONG).
 *
 * Lockout (5 wrong attempts = 5 min) and remaining attempts are shown.
 * On success: setResult(RESULT_OK) + finish().
 */
class AppLockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppLockBinding
    private lateinit var securityManager: SecurityManager
    private var recognizer: SpeechRecognizer? = null

    private val pinBuffer = StringBuilder()
    private val patternSelection = mutableListOf<Int>()

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceListen() else {
            binding.voiceStatusText.text = getString(R.string.voice_permission_needed)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        securityManager = SecurityManager(this)

        binding.pinTabButton.setOnClickListener { showTab(Tab.PIN) }
        binding.patternTabButton.setOnClickListener { showTab(Tab.PATTERN) }
        binding.voiceTabButton.setOnClickListener { showTab(Tab.VOICE) }
        binding.fingerTabButton.setOnClickListener { showTab(Tab.FINGER) }

        setupPinPad()
        setupPatternGrid()

        binding.voiceListenButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                startVoiceListen()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        binding.fingerButton.setOnClickListener { authenticateFingerprint() }

        updateLockoutText()
        showTab(Tab.PIN)
    }

    private enum class Tab { PIN, PATTERN, VOICE, FINGER }

    private fun showTab(tab: Tab) {
        binding.pinLayout.visibility = if (tab == Tab.PIN) View.VISIBLE else View.GONE
        binding.patternLayout.visibility = if (tab == Tab.PATTERN) View.VISIBLE else View.GONE
        binding.voiceLayout.visibility = if (tab == Tab.VOICE) View.VISIBLE else View.GONE
        binding.fingerLayout.visibility = if (tab == Tab.FINGER) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------ PIN

    private fun setupPinPad() {
        val buttons = listOf(
            binding.pinButton0, binding.pinButton1, binding.pinButton2,
            binding.pinButton3, binding.pinButton4, binding.pinButton5,
            binding.pinButton6, binding.pinButton7, binding.pinButton8,
            binding.pinButton9
        )
        buttons.forEachIndexed { digit, button ->
            button.setOnClickListener {
                if (pinBuffer.length < 12) {
                    pinBuffer.append(digit)
                    renderPinDisplay()
                }
            }
        }
        binding.pinClearButton.setOnClickListener {
            pinBuffer.clear()
            renderPinDisplay()
        }
        binding.pinUnlockButton.setOnClickListener { verifyPin() }
    }

    private fun renderPinDisplay() {
        binding.pinDisplay.text = "●".repeat(pinBuffer.length)
    }

    private fun verifyPin() {
        when (securityManager.verifyPin(pinBuffer.toString())) {
            SecurityManager.PinResult.CORRECT -> unlockSuccess()
            SecurityManager.PinResult.WRONG -> {
                pinBuffer.clear()
                renderPinDisplay()
                binding.lockoutText.text = getString(
                    R.string.wrong_pin_attempts, securityManager.remainingPinAttempts()
                )
                updateLockoutText()
            }
            SecurityManager.PinResult.NOT_SET -> {
                binding.lockoutText.text = getString(R.string.pin_not_set)
            }
            SecurityManager.PinResult.LOCKED_OUT -> updateLockoutText()
        }
    }

    // ------------------------------------------------------------ Pattern

    private fun setupPatternGrid() {
        val buttons = listOf(
            binding.patternButton0, binding.patternButton1, binding.patternButton2,
            binding.patternButton3, binding.patternButton4, binding.patternButton5,
            binding.patternButton6, binding.patternButton7, binding.patternButton8
        )
        buttons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (index !in patternSelection) {
                    patternSelection.add(index)
                    button.alpha = 0.45f
                    renderPatternStatus()
                }
            }
        }
        binding.patternClearButton.setOnClickListener { clearPatternSelection() }
        binding.patternVerifyButton.setOnClickListener { verifyPattern() }
    }

    private fun renderPatternStatus() {
        binding.patternStatusText.text = if (patternSelection.isEmpty()) {
            getString(R.string.pattern_draw)
        } else {
            patternSelection.joinToString(" → ") { (it + 1).toString() }
        }
    }

    private fun clearPatternSelection() {
        patternSelection.clear()
        listOf(
            binding.patternButton0, binding.patternButton1, binding.patternButton2,
            binding.patternButton3, binding.patternButton4, binding.patternButton5,
            binding.patternButton6, binding.patternButton7, binding.patternButton8
        ).forEach { it.alpha = 1f }
        renderPatternStatus()
    }

    private fun verifyPattern() {
        if (patternSelection.size < 4) {
            binding.patternStatusText.text = getString(R.string.pattern_too_short)
            return
        }
        when (
            securityManager.verifyPattern(patternSelection.joinToString(","))
        ) {
            SecurityManager.PinResult.CORRECT -> unlockSuccess()
            SecurityManager.PinResult.WRONG -> {
                clearPatternSelection()
                binding.lockoutText.text = getString(
                    R.string.wrong_pattern_attempts,
                    securityManager.remainingPatternAttempts()
                )
            }
            SecurityManager.PinResult.NOT_SET -> {
                binding.lockoutText.text = getString(R.string.pattern_not_set)
            }
            SecurityManager.PinResult.LOCKED_OUT -> updateLockoutText()
        }
    }

    // ------------------------------------------------------------ Voice

    private fun startVoiceListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            binding.voiceStatusText.text = getString(R.string.voice_unavailable)
            return
        }
        binding.voiceStatusText.text = getString(R.string.listening)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onResults(results: Bundle?) {
                val heard = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (heard.isBlank()) {
                    binding.voiceStatusText.text = getString(R.string.voice_not_heard)
                    return
                }
                if (!securityManager.hasVoicePassphrase()) {
                    binding.voiceStatusText.text = getString(R.string.voice_not_set)
                    return
                }
                if (securityManager.verifyVoicePassphrase(heard)) {
                    unlockSuccess()
                } else {
                    binding.voiceStatusText.text = getString(R.string.voice_no_match)
                }
            }

            override fun onError(error: Int) {
                binding.voiceStatusText.text = getString(R.string.voice_not_heard)
            }
        })
        try {
            sr.startListening(intent)
        } catch (e: Exception) {
            binding.voiceStatusText.text = getString(R.string.voice_unavailable)
        }
    }

    // ------------------------------------------------------------ Fingerprint

    private fun authenticateFingerprint() {
        if (!BiometricManager.isAvailable(this)) {
            binding.fingerStatusText.text = getString(R.string.biometric_unavailable)
            return
        }
        securityManager.authenticateWithBiometric(
            activity = this,
            onSuccess = { unlockSuccess() },
            onError = { message -> binding.fingerStatusText.text = message }
        )
    }

    // ------------------------------------------------------------ shared

    private fun updateLockoutText() {
        val remaining = securityManager.pinLockoutRemainingMillis()
        if (remaining > 0) {
            val minutes = (remaining / 60_000L).coerceAtLeast(1L)
            binding.lockoutText.text = getString(R.string.locked_out_minutes, minutes)
        } else if (binding.lockoutText.text.isNullOrBlank()) {
            binding.lockoutText.text = ""
        }
    }

    private fun unlockSuccess() {
        Toast.makeText(this, R.string.unlocked, Toast.LENGTH_SHORT).show()
        setResult(RESULT_OK)
        finish()
    }

    override fun onDestroy() {
        runCatching { recognizer?.destroy() }
        recognizer = null
        super.onDestroy()
    }
}
