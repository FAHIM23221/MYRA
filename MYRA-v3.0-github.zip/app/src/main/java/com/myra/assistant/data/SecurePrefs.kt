package com.myra.assistant.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger

/**
 * Preferences split by sensitivity:
 * - API keys live in EncryptedSharedPreferences (MasterKey AES256_GCM).
 * - Everything else lives in plain SharedPreferences under [Constants.PREFS_NAME].
 *
 * No key value is ever logged.
 */
class SecurePrefs(context: Context) {

    private val appContext: Context = context.applicationContext

    private val securePrefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            Constants.SECURE_PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private val prefs: SharedPreferences by lazy {
        appContext.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
    }

    // ---- API keys (encrypted) ----
    fun getApiKey(): String? = securePrefs.getString(Constants.KEY_API_KEY, null)

    fun setApiKey(apiKey: String) {
        securePrefs.edit().putString(Constants.KEY_API_KEY, apiKey).apply()
    }

    fun clearApiKey() {
        securePrefs.edit().remove(Constants.KEY_API_KEY).apply()
        Logger.i("SecurePrefs", "Gemini API key cleared")
    }

    fun getTtsKey(): String? = securePrefs.getString(Constants.KEY_TTS_API_KEY, null)

    fun setTtsKey(ttsKey: String) {
        securePrefs.edit().putString(Constants.KEY_TTS_API_KEY, ttsKey).apply()
    }

    fun clearTtsKey() {
        securePrefs.edit().remove(Constants.KEY_TTS_API_KEY).apply()
    }

    // ---- Non-sensitive settings (plain prefs) ----
    fun getString(key: String, default: String): String =
        prefs.getString(key, default) ?: default

    fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getBoolean(key: String, default: Boolean): Boolean =
        prefs.getBoolean(key, default)

    fun putBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    fun getInt(key: String, default: Int): Int =
        prefs.getInt(key, default)

    fun putInt(key: String, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }

    fun getLong(key: String, default: Long): Long =
        prefs.getLong(key, default)

    fun putLong(key: String, value: Long) {
        prefs.edit().putLong(key, value).apply()
    }

    /** Convenience: has the owner consented to MYRA remembering things? */
    fun hasMemoryConsent(): Boolean =
        getBoolean(Constants.KEY_MEMORY_CONSENT, false)

    fun setMemoryConsent(consented: Boolean) {
        putBoolean(Constants.KEY_MEMORY_CONSENT, consented)
    }
}
