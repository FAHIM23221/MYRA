package com.myra.assistant.voice

import android.util.Base64
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live (streaming) client for the Gemini Live API over WebSocket.
 *
 * The API key is used only to build the connection URL and is NEVER logged.
 * Audio bytes are never logged either — only their lengths.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val listener: LiveListener
) {
    interface LiveListener {
        fun onConnected()
        fun onTextReceived(text: String)
        fun onAudioReceived(pcm16: ByteArray)
        fun onTurnComplete()
        fun onError(msg: String)
        fun onDisconnected()
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // long-lived streaming socket
        .pingInterval(30, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null

    @Volatile
    var isConnected: Boolean = false
        private set

    fun connect() {
        if (isConnected) return
        val url = Constants.GEMINI_WS_BASE + "?key=" + apiKey
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, socketListener)
    }

    private fun sendSetup() {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", Constants.GEMINI_LIVE_MODEL)
                put("generation_config", JSONObject().apply {
                    put("response_modalities", JSONArray().put("AUDIO"))
                    put("speech_config", JSONObject().apply {
                        put("voice_config", JSONObject().apply {
                            put("prebuilt_voice_config", JSONObject().apply {
                                put("voice_name", Constants.GEMINI_VOICE)
                            })
                        })
                    })
                })
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().apply {
                        put(
                            "text",
                            "You are MYRA, a caring AI companion. " +
                                "Respond in Bengali and English as the user speaks."
                        )
                    }))
                })
            })
        }
        sendRaw(setup.toString())
    }

    /** Send one chunk of 16 kHz mono PCM16 audio, base64-encoded. */
    fun sendAudioChunk(base64Pcm16: String) {
        if (!isConnected) return
        val payload = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(JSONObject().apply {
                    put("mimeType", "audio/pcm")
                    put("data", base64Pcm16)
                }))
            })
        }
        sendRaw(payload.toString())
    }

    /** Convenience overload: raw PCM16 bytes are base64-encoded here. */
    fun sendAudioChunk(pcm16: ByteArray) {
        val base64 = Base64.encodeToString(pcm16, Base64.NO_WRAP)
        sendAudioChunk(base64)
    }

    /** Send a text turn and mark it complete so the model replies. */
    fun sendTextMessage(text: String) {
        if (!isConnected) return
        val payload = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().apply {
                        put("text", text)
                    }))
                }))
                put("turnComplete", true)
            })
        }
        sendRaw(payload.toString())
    }

    fun disconnect() {
        try {
            socket?.close(1000, "Client disconnect")
        } catch (e: Exception) {
            Logger.e("GeminiLiveClient", "disconnect failed", e)
        }
        socket = null
        isConnected = false
    }

    private fun sendRaw(json: String): Boolean {
        val ws = socket ?: return false
        return try {
            ws.send(json)
        } catch (e: Exception) {
            Logger.e("GeminiLiveClient", "send failed", e)
            false
        }
    }

    private val socketListener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            isConnected = true
            Logger.i("GeminiLiveClient", "WebSocket opened")
            sendSetup()
            listener.onConnected()
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                parseServerMessage(text)
            } catch (e: Exception) {
                Logger.e("GeminiLiveClient", "Failed to parse server message", e)
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            isConnected = false
            webSocket.close(1000, null)
            listener.onDisconnected()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            isConnected = false
            Logger.e("GeminiLiveClient", "WebSocket failure: ${t.message}", t)
            listener.onError("Live connection failed. / লাইভ সংযোগ ব্যর্থ হয়েছে।")
            listener.onDisconnected()
        }
    }

    private fun parseServerMessage(text: String) {
        val root = JSONObject(text)
        if (root.has("setupComplete")) return

        val serverContent = root.optJSONObject("serverContent") ?: return

        if (serverContent.optBoolean("turnComplete", false)) {
            listener.onTurnComplete()
        }
        val modelTurn = serverContent.optJSONObject("modelTurn") ?: return
        val parts = modelTurn.optJSONArray("parts") ?: return
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val partText = part.optString("text", "")
            if (partText.isNotEmpty()) {
                listener.onTextReceived(partText)
            }
            val inlineData = part.optJSONObject("inlineData")
            val audioBase64 = inlineData?.optString("data", "").orEmpty()
            if (audioBase64.isNotEmpty()) {
                val pcm = Base64.decode(audioBase64, Base64.DEFAULT)
                Logger.d("GeminiLiveClient", "Received audio chunk (${pcm.size} bytes)")
                listener.onAudioReceived(pcm)
            }
        }
    }
}
