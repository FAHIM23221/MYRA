package com.myra.assistant.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myra.assistant.MyraApplication
import com.myra.assistant.ai.CommandProcessor
import com.myra.assistant.data.ReminderEntity
import com.myra.assistant.models.ChatMessage
import com.myra.assistant.models.CommandType
import com.myra.assistant.models.OrbState
import com.myra.assistant.models.PersonalityMode
import com.myra.assistant.models.SessionRole
import com.myra.assistant.models.VoiceCommand
import com.myra.assistant.screen.ScreenVision
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.voice.VoiceManager
import com.myra.assistant.work.ReminderWorker
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.Calendar

/**
 * Wired against the real data / AI / voice layer:
 * - VoiceManager(context, onResult, onError, onState); isListening is a var.
 * - ConversationManager.respond(text, prefs: Map<String, String>): Result<String> (suspend).
 * - DeviceController methods return Boolean; toggleFlashlight(on), setAlarm(h, m, label).
 * - ScreenVision(context).describeCurrentScreen(elements) / findElement(elements, query).
 * - AccessibilityHelperService.getCurrentElements() is a companion call; clicking
 *   goes through the live service instance (AccessibilityHelperService.instance).
 */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val myraApp = app as MyraApplication
    private val repository = myraApp.repository
    private val securePrefs = myraApp.securePrefs
    private val conversation = myraApp.conversation

    private val deviceController =
        com.myra.assistant.automation.DeviceController(app.applicationContext)
    private val screenVision = ScreenVision(app.applicationContext)
    private val voiceManager = VoiceManager(
        app.applicationContext,
        { text -> onTextSubmitted(text) },
        { message ->
            _error.postValue(message)
            _orbState.postValue(OrbState.ERROR)
        },
        { state -> _orbState.postValue(state) }
    )

    private val _messages = MutableLiveData<List<ChatMessage>>(emptyList())
    val messages: LiveData<List<ChatMessage>> = _messages

    private val _orbState = MutableLiveData(OrbState.IDLE)
    val orbState: LiveData<OrbState> = _orbState

    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    private val _sessionRole = MutableLiveData(conversation.currentRole)
    val sessionRole: LiveData<SessionRole> = _sessionRole

    /** Set when FIND_ON_SCREEN found something and MYRA asked for confirmation. */
    private var pendingAction: (() -> Unit)? = null
    private var pendingActionLabel: String? = null

    private var memoryContextCache = ""

    init {
        postMyra("হ্যালো Olivia! আমি MYRA — বলো, কী করতে পারি?", speak = false)
    }

    // ------------------------------------------------------------ mic / speech

    fun onMicTapped() {
        if (voiceManager.isListening) {
            runCatching { voiceManager.stopListening() }
            _orbState.postValue(OrbState.IDLE)
        } else {
            _error.postValue(null)
            _orbState.postValue(OrbState.LISTENING)
            runCatching { voiceManager.startListening() }.onFailure {
                _orbState.postValue(OrbState.ERROR)
                _error.postValue("Microphone শুরু করা যায়নি — permission চেক করো।")
            }
        }
    }

    /** Long-press mic: stop speaking immediately (barge-in). */
    fun bargeIn() {
        runCatching { voiceManager.stopSpeaking() }
        _orbState.postValue(OrbState.IDLE)
    }

    fun stopSpeaking() = bargeIn()

    fun speakReply(text: String) {
        if (text.isBlank()) return
        _orbState.postValue(OrbState.SPEAKING)
        runCatching {
            voiceManager.speak(text) { _orbState.postValue(OrbState.IDLE) }
        }.onFailure {
            _orbState.postValue(OrbState.IDLE)
        }
    }

    // ------------------------------------------------------------ messages

    fun onTextSubmitted(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        appendMessage(
            ChatMessage(
                text = trimmed,
                isUser = true,
                role = _sessionRole.value ?: SessionRole.OWNER
            )
        )

        // A pending FIND_ON_SCREEN confirmation is answered first.
        if (pendingAction != null) {
            val lower = trimmed.lowercase().trimEnd('.', '!', '?', '।')
            if (lower in YES_WORDS) {
                val action = pendingAction
                pendingAction = null
                pendingActionLabel = null
                val done = runCatching { action?.invoke() }.isSuccess
                postMyra(if (done) "করে দিলাম ✓" else "Tap করতে পারলাম না।")
                return
            }
            if (lower in NO_WORDS) {
                pendingAction = null
                pendingActionLabel = null
                postMyra("ঠিক আছে, করছি না।")
                return
            }
            // Anything else cancels the pending tap and is handled normally.
            pendingAction = null
            pendingActionLabel = null
        }

        viewModelScope.launch {
            _orbState.postValue(OrbState.PROCESSING)
            try {
                val cmd = CommandProcessor.parse(trimmed)
                when (cmd.type) {
                    CommandType.LOOK_AT_SCREEN, CommandType.EXPLAIN_SCREEN,
                    CommandType.READ_SCREEN, CommandType.FIND_ON_SCREEN -> {
                        executeScreenCommand(cmd)
                    }
                    CommandType.UNKNOWN -> respondWithAi(trimmed)
                    else -> postMyra(executeCommand(cmd))
                }
            } catch (e: Exception) {
                Logger.e("MainViewModel", "onTextSubmitted failed", e)
                _error.postValue("কিছু একটা ভুল হয়েছে — আবার চেষ্টা করো।")
            } finally {
                if (_orbState.value == OrbState.PROCESSING) {
                    _orbState.postValue(OrbState.IDLE)
                }
            }
        }
    }

    private suspend fun respondWithAi(text: String) {
        val result = runCatching { conversation.respond(text, prefsMap()) }
            .getOrElse { Result.failure(it) }
        val reply = result.getOrNull()
        if (!reply.isNullOrBlank()) {
            postMyra(reply)
        } else {
            _error.postValue("Gemini-তে সমস্যা হয়েছে — API key / নেট চেক করো (Settings)।")
            postMyra(
                "দুঃখিত, এখন উত্তর দিতে পারছি না। API key আর ইন্টারনেট চেক করে আবার বলো।",
                speak = false
            )
        }
    }

    private fun prefsMap(): Map<String, String> = mapOf(
        Constants.KEY_USER_NAME to
            securePrefs.getString(Constants.KEY_USER_NAME, "Olivia"),
        Constants.KEY_PERSONALITY to
            securePrefs.getString(Constants.KEY_PERSONALITY, PersonalityMode.ASSISTANT.name),
        Constants.KEY_LANGUAGE to
            securePrefs.getString(Constants.KEY_LANGUAGE, "auto")
    )

    // ------------------------------------------------------------ direct commands

    private suspend fun executeCommand(cmd: VoiceCommand): String {
        val arg = cmd.arg?.trim().orEmpty()
        return try {
            when (cmd.type) {
                CommandType.OPEN_APP -> {
                    if (arg.isEmpty()) "কোন অ্যাপ খুলবো?"
                    else if (deviceController.openApp(arg)) "খুলছি: $arg"
                    else "“$arg” অ্যাপটা খুঁজে পেলাম না।"
                }
                CommandType.CALL -> {
                    if (arg.isEmpty()) "কাকে কল করবো? নাম্বারটা বলো।"
                    else if (deviceController.makeCall(arg)) "কল করছি: $arg"
                    else "কল করতে পারলাম না — নাম্বার / permission চেক করো।"
                }
                CommandType.WHATSAPP_CALL -> {
                    if (deviceController.openApp("WhatsApp")) "WhatsApp খুলছি — ওখান থেকে কল করো।"
                    else "WhatsApp খুঁজে পেলাম না।"
                }
                CommandType.SMS -> {
                    val body = cmd.arg2.orEmpty()
                    if (arg.isEmpty() || body.isEmpty()) "SMS পাঠাতে নাম্বার আর মেসেজ — দুটোই লাগবে।"
                    else if (deviceController.sendSms(arg, body)) "$arg-এ SMS পাঠিয়ে দিলাম।"
                    else "SMS পাঠাতে পারলাম না — permission চেক করো।"
                }
                CommandType.FLASHLIGHT_ON -> {
                    if (deviceController.toggleFlashlight(true)) "ফ্ল্যাশলাইট জ্বালিয়ে দিলাম।"
                    else "ফ্ল্যাশলাইট চালাতে পারলাম না।"
                }
                CommandType.FLASHLIGHT_OFF -> {
                    if (deviceController.toggleFlashlight(false)) "ফ্ল্যাশলাইট বন্ধ করে দিলাম।"
                    else "ফ্ল্যাশলাইট বন্ধ করতে পারলাম না।"
                }
                CommandType.VOLUME_UP -> {
                    deviceController.setVolumeUp()
                    "ভলিউম বাড়িয়ে দিলাম।"
                }
                CommandType.VOLUME_DOWN -> {
                    deviceController.setVolumeDown()
                    "ভলিউম কমিয়ে দিলাম।"
                }
                CommandType.SET_ALARM -> {
                    val time = parseAlarmTime(cmd.arg.orEmpty())
                    if (time == null) {
                        "কয়টায় অ্যালার্ম দেবো? যেমন: “set alarm 7:30”"
                    } else {
                        val (hour, minute) = time
                        if (deviceController.setAlarm(hour, minute, "MYRA alarm")) {
                            "অ্যালার্ম সেট করলাম: %02d:%02d".format(hour, minute)
                        } else "অ্যালার্ম সেট করতে পারলাম না।"
                    }
                }
                CommandType.SET_REMINDER -> handleSetReminder(cmd)
                CommandType.CREATE_NOTE -> {
                    if (arg.isEmpty()) "নোটে কী লিখবো?"
                    else if (deviceController.createNote(arg)) "নোট লিখে রাখলাম।"
                    else "নোট লিখতে পারলাম না।"
                }
                CommandType.SEARCH -> {
                    if (arg.isEmpty()) "কী খুঁজবো?"
                    else if (deviceController.searchWeb(arg)) "খুঁজছি: $arg"
                    else "খুঁজতে পারলাম না।"
                }
                CommandType.PLAY_MUSIC, CommandType.SPOTIFY_PLAY -> {
                    if (deviceController.openApp("Spotify")) "Spotify খুলছি।"
                    else "Spotify খুঁজে পেলাম না।"
                }
                else -> "বুঝতে পারিনি — আবার বলো তো।"
            }
        } catch (e: Exception) {
            Logger.e("MainViewModel", "Command failed: ${cmd.type}", e)
            "এই কাজটা করতে পারলাম না।"
        }
    }

    private suspend fun handleSetReminder(cmd: VoiceCommand): String {
        val raw = cmd.arg.orEmpty()
        // Prefer a time expression that actually carries minutes or am/pm
        // ("7:30", "7 pm") over a bare number inside the title ("buy 2 tickets").
        val match = REMINDER_TIME_REGEX.findAll(raw)
            .maxByOrNull { m ->
                var score = 0
                if (!m.groupValues.getOrNull(2).isNullOrEmpty()) score += 2
                if (!m.groupValues.getOrNull(3).isNullOrEmpty()) score += 2
                score
            } ?: return "কয়টায় মনে করিয়ে দেবো? যেমন: “remind me to call mom at 7:30”"
        val time = parseReminderTimeMatch(match)
            ?: return "সময়টা বুঝতে পারিনি — যেমন “7:30” বা “7 pm” বলো।"
        val (hour, minute) = time
        var title = raw.replace(match.value, " ").trim()
            .replace(Regex("^(remind me to|set reminder|মনে করিয়ে দাও|রিমাইন্ডার দাও)\\s*", RegexOption.IGNORE_CASE), "")
            .trim().trimEnd('.', '!', '।')
        if (title.isBlank()) title = "Reminder"
        val trigger = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        runCatching {
            repository.saveReminder(ReminderEntity(title = title, triggerAtMillis = trigger))
            ReminderWorker.schedule(getApplication())
        }.onFailure { e ->
            Logger.e("MainViewModel", "Could not save reminder", e)
            return "রিমাইন্ডার রাখতে পারলাম না।"
        }
        return "মনে করিয়ে দেবো: $title — %02d:%02d".format(hour, minute)
    }

    private fun parseAlarmTime(arg: String): Pair<Int, Int>? {
        val match = Regex("(\\d{1,2})[:.](\\d{2})").find(arg)
        if (match != null) {
            val h = match.groupValues[1].toIntOrNull() ?: return null
            val m = match.groupValues[2].toIntOrNull() ?: return null
            if (h in 0..23 && m in 0..59) return h to m
        }
        val hourOnly = arg.trim().toIntOrNull()
        if (hourOnly != null && hourOnly in 0..23) return hourOnly to 0
        return null
    }

    private fun parseReminderTimeMatch(match: MatchResult): Pair<Int, Int>? {
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        val ampm = match.groupValues.getOrNull(3)?.lowercase().orEmpty()
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) return null
        return hour to minute
    }

    // ------------------------------------------------------------ screen commands

    /** Public entry point (e.g. from UI buttons). Runs async. */
    fun onScreenCommand(cmd: VoiceCommand) {
        viewModelScope.launch {
            _orbState.postValue(OrbState.PROCESSING)
            try {
                executeScreenCommand(cmd)
            } finally {
                if (_orbState.value == OrbState.PROCESSING) {
                    _orbState.postValue(OrbState.IDLE)
                }
            }
        }
    }

    private suspend fun executeScreenCommand(cmd: VoiceCommand) {
        try {
            val elements = AccessibilityHelperService.getCurrentElements()
            when (cmd.type) {
                CommandType.LOOK_AT_SCREEN, CommandType.EXPLAIN_SCREEN, CommandType.READ_SCREEN -> {
                    val description = screenVision.describeCurrentScreen(elements)
                    postMyra(description)
                }
                CommandType.FIND_ON_SCREEN -> {
                    val query = cmd.arg.orEmpty()
                    val found = screenVision.findElement(elements, query)
                    if (found != null) {
                        val service = AccessibilityHelperService.instance
                        if (service == null) {
                            postMyra(
                                "“${found.text.ifBlank { query }}” পেয়েছি, কিন্তু Tap করতে Accessibility service চালু থাকতে হবে।",
                                speak = false
                            )
                            return
                        }
                        pendingAction = {
                            runCatching { service.performClickOn(found) }
                        }
                        pendingActionLabel = found.text.ifBlank { query }
                        postMyra("“$pendingActionLabel”-এ Tap করবো? হ্যাঁ বললে করছি।")
                    } else {
                        postMyra("“$query” স্ক্রিনে খুঁজে পেলাম না।")
                    }
                }
                else -> Unit
            }
        } catch (e: Exception) {
            Logger.e("MainViewModel", "Screen command failed", e)
            _error.postValue("স্ক্রিন পড়তে পারলাম না — Accessibility service চালু আছে তো?")
            postMyra("স্ক্রিনটা দেখতে পারছি না। Accessibility service অন করো।", speak = false)
        }
    }

    // ------------------------------------------------------------ sessions / memory

    fun startGuestMode() {
        conversation.startGuestSession()
        _sessionRole.value = SessionRole.GUEST
        postMyra("Guest mode চালু — তোমার private memory লুকানো থাকবে।", speak = false)
    }

    fun endGuestMode() {
        conversation.endGuestSession()
        _sessionRole.value = SessionRole.OWNER
        postMyra("Guest mode বন্ধ — স্বাগতম, Olivia!", speak = false)
    }

    fun switchToOwner() {
        conversation.switchToOwner()
        _sessionRole.value = SessionRole.OWNER
    }

    fun clearError() {
        _error.value = null
    }

    fun loadMemoryContextSummary(): String {
        return try {
            val summary = runBlocking { repository.buildMemoryContext() }
            memoryContextCache = summary
            summary
        } catch (e: Exception) {
            Logger.e("MainViewModel", "Memory context failed", e)
            memoryContextCache
        }
    }

    // ------------------------------------------------------------ helpers

    private fun postMyra(text: String, speak: Boolean = true) {
        appendMessage(
            ChatMessage(
                text = text,
                isUser = false,
                role = _sessionRole.value ?: SessionRole.OWNER
            )
        )
        if (speak) speakReply(text)
    }

    private fun appendMessage(message: ChatMessage) {
        _messages.postValue(_messages.value.orEmpty() + message)
    }

    override fun onCleared() {
        runCatching { voiceManager.destroy() }
        super.onCleared()
    }

    companion object {
        private val YES_WORDS = setOf(
            "হ্যাঁ", "হ্যা", "yes", "yeah", "yep", "ok", "okay", "করো", "হুম", "ঠিক আছে"
        )
        private val NO_WORDS = setOf("না", "no", "nope", "করো না", "থাক", "লাগবে না")

        /** e.g. "7:30", "7:30 pm", "7 pm". Group 1 = hour, 2 = minute?, 3 = am/pm? */
        private val REMINDER_TIME_REGEX =
            Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE)
    }
}
