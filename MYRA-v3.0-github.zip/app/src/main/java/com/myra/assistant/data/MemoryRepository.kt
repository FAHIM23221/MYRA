package com.myra.assistant.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.myra.assistant.models.ContactProfile
import com.myra.assistant.models.Mood
import com.myra.assistant.models.SessionRole
import com.myra.assistant.utils.Logger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * The single gatekeeper for everything MYRA remembers.
 *
 * Nothing is stored unless the owner gave explicit memory consent
 * ([Constants.KEY_MEMORY_CONSENT]). Guests and contacts never get private
 * memory, and turns are only saved for the owner.
 */
class MemoryRepository(
    @Suppress("unused") private val context: Context,
    private val dao: MyraDao,
    private val securePrefs: SecurePrefs
) {
    private val gson = Gson()

    private fun hasConsent(): Boolean = securePrefs.hasMemoryConsent()

    // ---- Memories ----
    suspend fun saveMemory(key: String, value: String, category: String = "general"): Boolean {
        if (!hasConsent()) {
            Logger.w("MemoryRepository", "saveMemory refused: no memory consent")
            return false
        }
        if (key.isBlank() || value.isBlank()) return false
        val now = System.currentTimeMillis()
        val existing = dao.getMemoryByKey(key)
        dao.insertMemory(
            MemoryEntity(
                id = existing?.id ?: 0,
                key = key,
                value = value,
                category = category,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now,
                sourceConsent = true
            )
        )
        return true
    }

    suspend fun getMemory(key: String): String? {
        if (!hasConsent()) return null
        return dao.getMemoryByKey(key)?.value
    }

    fun getAllMemories(): Flow<List<MemoryEntity>> = dao.getAllMemories()

    fun searchMemories(query: String): Flow<List<MemoryEntity>> =
        if (query.isBlank()) dao.getAllMemories() else dao.searchMemories(query)

    fun searchMemoriesByCategory(category: String): Flow<List<MemoryEntity>> =
        dao.searchMemoriesByCategory(category)

    suspend fun deleteMemory(id: Long) {
        dao.deleteMemoryById(id)
    }

    suspend fun deleteMemoryByKey(key: String) {
        dao.deleteMemoryByKey(key)
    }

    suspend fun deleteAllMemories() {
        dao.clearMemories()
    }

    /** JSON export of stored memories. Contains no API keys or secrets. */
    suspend fun exportMemories(): String {
        if (!hasConsent()) return "[]"
        val memories = dao.getAllMemories().first()
        return gson.toJson(memories)
    }

    /** Imports memories from [exportMemories] JSON. Returns the number imported. */
    suspend fun importMemories(json: String): Int {
        if (!hasConsent()) return 0
        if (json.isBlank()) return 0
        return try {
            val type = object : TypeToken<List<MemoryEntity>>() {}.type
            val memories: List<MemoryEntity> = gson.fromJson(json, type) ?: return 0
            var count = 0
            for (memory in memories) {
                if (memory.key.isBlank() || memory.value.isBlank()) continue
                dao.insertMemory(memory.copy(id = 0, sourceConsent = true))
                count++
            }
            count
        } catch (e: Exception) {
            Logger.e("MemoryRepository", "importMemories failed: invalid JSON", e)
            0
        }
    }

    // ---- Contacts ----
    suspend fun saveContact(profile: ContactProfile): Long {
        val entity = ContactEntity(
            id = profile.id,
            name = profile.name,
            relationship = profile.relationship,
            preferredAddress = profile.preferredAddress,
            notes = profile.notes,
            phoneNumber = profile.phoneNumber,
            enrolledByOwner = profile.enrolledByOwner,
            facePresentInPhoto = profile.facePresentInPhoto
        )
        return dao.insertContact(entity)
    }

    fun getContacts(): Flow<List<ContactProfile>> =
        dao.getAllContacts().map { entities ->
            entities.map { e ->
                ContactProfile(
                    id = e.id,
                    name = e.name,
                    relationship = e.relationship,
                    preferredAddress = e.preferredAddress,
                    notes = e.notes,
                    phoneNumber = e.phoneNumber,
                    enrolledByOwner = e.enrolledByOwner,
                    facePresentInPhoto = e.facePresentInPhoto
                )
            }
        }

    suspend fun deleteContact(id: Long) {
        dao.deleteContactById(id)
    }

    // ---- Reminders ----
    suspend fun saveReminder(reminder: ReminderEntity): Long =
        dao.insertReminder(reminder)

    suspend fun deleteReminder(id: Long) {
        dao.deleteReminderById(id)
    }

    suspend fun updateReminder(reminder: ReminderEntity) {
        dao.updateReminder(reminder)
    }

    suspend fun getDueReminders(now: Long): List<ReminderEntity> =
        dao.getDueReminders(now)

    // ---- Routines ----
    suspend fun saveRoutine(routine: RoutineEntity): Long =
        dao.insertRoutine(routine)

    fun getAllRoutines(): Flow<List<RoutineEntity>> = dao.getAllRoutines()

    suspend fun deleteRoutine(id: Long) {
        dao.deleteRoutineById(id)
    }

    // ---- Turns ----
    suspend fun saveTurn(
        text: String,
        isUser: Boolean,
        role: SessionRole = SessionRole.OWNER,
        mood: Mood? = null
    ) {
        if (!hasConsent()) return
        if (role != SessionRole.OWNER) return
        if (text.isBlank()) return
        dao.insertTurn(
            TurnEntity(
                role = role.name,
                text = text,
                isUser = isUser,
                mood = mood?.name
            )
        )
    }

    suspend fun getRecentTurns(limit: Int): List<TurnEntity> =
        dao.getRecentTurns(limit)

    suspend fun deleteAllTurns() {
        dao.deleteAllTurns()
    }

    /**
     * Builds the memory + recent-turn context injected into the AI system prompt.
     * Returns "" when there is no consent or nothing stored.
     */
    suspend fun buildMemoryContext(maxChars: Int = 2000): String {
        if (!hasConsent()) return ""
        val memories = try {
            dao.getAllMemories().first()
        } catch (e: Exception) {
            Logger.e("MemoryRepository", "buildMemoryContext: could not load memories", e)
            emptyList()
        }
        val turns = try {
            dao.getRecentTurns(10)
        } catch (e: Exception) {
            Logger.e("MemoryRepository", "buildMemoryContext: could not load turns", e)
            emptyList()
        }
        if (memories.isEmpty() && turns.isEmpty()) return ""
        val sb = StringBuilder()
        if (memories.isNotEmpty()) {
            sb.append("Things to remember about the owner:\n")
            for (m in memories) {
                sb.append("- ${m.key}: ${m.value} (${m.category})\n")
            }
        }
        if (turns.isNotEmpty()) {
            sb.append("Recent conversation:\n")
            for (t in turns.asReversed()) {
                val speaker = if (t.isUser) "Owner" else "MYRA"
                sb.append("$speaker: ${t.text}\n")
            }
        }
        val text = sb.toString()
        return if (text.length > maxChars) text.take(maxChars) else text
    }
}
