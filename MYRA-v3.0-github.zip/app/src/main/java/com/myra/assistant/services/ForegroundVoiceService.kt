package com.myra.assistant.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import com.myra.assistant.MyraApplication
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.voice.VoiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground voice service: keeps MYRA listening in the background.
 *
 * Flow: ACTION_START_LISTENING -> VoiceManager listens -> result ->
 * ConversationManager.respond -> reply spoken aloud.
 *
 * Wake word: the text is treated as a wake-word hit when it contains the
 * configured word (KEY_WAKE_WORD, default "myra"), case-insensitive.
 * NOTE: always-on hotword detection here uses SpeechRecognizer continuous
 * mode ONLY when the user has enabled background mode; it can be disabled
 * at any time by turning background mode off or stopping the service.
 */
class ForegroundVoiceService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var voiceManager: VoiceManager? = null
    private var wakeWord: String = DEFAULT_WAKE_WORD

    private val prefs: SharedPreferences by lazy {
        getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onCreate() {
        super.onCreate()
        wakeWord = prefs.getString(Constants.KEY_WAKE_WORD, DEFAULT_WAKE_WORD)
            ?.trim().orEmpty().ifEmpty { DEFAULT_WAKE_WORD }
        createNotificationChannel()
        startForeground(Constants.NOTIF_ID_VOICE, buildNotification())
        voiceManager = VoiceManager(
            context = this,
            onResult = { text -> onHeard(text) },
            onError = { message -> Logger.w("ForegroundVoiceService", "Voice error: $message") },
            onState = { state -> Logger.d("ForegroundVoiceService", "Orb state: $state") }
        )
        Logger.i("ForegroundVoiceService", "Service created (wake word configured)")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Constants.ACTION_START_LISTENING -> {
                voiceManager?.startListening()
            }
            Constants.ACTION_STOP_LISTENING -> {
                voiceManager?.stopListening()
                voiceManager?.stopSpeaking()
            }
            else -> {
                // Started (e.g. after boot) without an action: stay ready, do
                // not listen until the user asks — no always-on mic by default.
                Logger.i("ForegroundVoiceService", "Service started without listen action")
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        serviceScope.cancel()
        voiceManager?.destroy()
        voiceManager = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** A recognised utterance: answer it through the conversation manager. */
    private fun onHeard(text: String) {
        Logger.d("ForegroundVoiceService", "Heard utterance (length=${text.length})")
        val app = application as? MyraApplication ?: run {
            Logger.e("ForegroundVoiceService", "MyraApplication not available")
            return
        }
        serviceScope.launch(Dispatchers.IO) {
            // ConversationManager.respond takes a Map<String, String> of prefs.
            val prefsMap = mapOf(
                Constants.KEY_USER_NAME to
                    (prefs.getString(Constants.KEY_USER_NAME, "friend") ?: "friend"),
                Constants.KEY_PERSONALITY to
                    (prefs.getString(Constants.KEY_PERSONALITY, "ASSISTANT") ?: "ASSISTANT")
            )
            val result = runCatching { app.conversation.respond(text, prefsMap) }
                .getOrElse { Result.failure(it) }
            val reply = result.getOrNull()
            if (reply.isNullOrBlank()) {
                Logger.w("ForegroundVoiceService", "Empty reply from conversation manager")
                serviceScope.launch(Dispatchers.Main) {
                    voiceManager?.speak("Sorry, I couldn't answer that right now. / দুঃখিত, এখন উত্তর দিতে পারছি না।")
                }
                return@launch
            }
            serviceScope.launch(Dispatchers.Main) {
                voiceManager?.speak(reply)
            }
        }
    }

    /**
     * True when [text] contains the configured wake word (case-insensitive).
     * Default wake word is "myra".
     */
    fun isWakeWord(text: String): Boolean {
        if (text.isBlank()) return false
        return text.lowercase().contains(wakeWord.lowercase())
    }

    // ------------------------------------------------------------ notification

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            Constants.NOTIF_CHANNEL_VOICE,
            "MYRA voice",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "MYRA is listening in the background" }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent().apply {
            setClassName(packageName, "com.myra.assistant.ui.main.MainActivity")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, Constants.NOTIF_CHANNEL_VOICE)
            .setContentTitle("MYRA is listening")
            .setContentText("MYRA is listening — tap to open")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val DEFAULT_WAKE_WORD = "myra"

        fun startListening(context: Context) {
            val intent = Intent(context, ForegroundVoiceService::class.java).apply {
                action = Constants.ACTION_START_LISTENING
            }
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }

        fun stopListening(context: Context) {
            val intent = Intent(context, ForegroundVoiceService::class.java).apply {
                action = Constants.ACTION_STOP_LISTENING
            }
            context.startService(intent)
        }
    }
}
